> **IMPORTANT — MIXED-ORIGIN LICENSING / NO UPSTREAM INTEGRATION PERMISSION FOR VERIFIED RESERVED ADDITIONS**  
> This independent fork includes code originally licensed under Apache-2.0/MIT and new paths of unverified origin. Only *future or otherwise verified*, separately marked and legally eligible copyrighted additions can be reserved under [the restricted notice](LICENSE-ORIGINAL-ADDITIONS.md); there are presently no certified restricted source entries. **No authorization is offered to incorporate any such qualifying reserved additions into official `simdjson/simdjson` without signed permission.** All earlier upstream and permissive rights remain effective. See [LICENSE](LICENSE), [scope](LICENSE-SCOPE.md), [provenance](PROVENANCE-ADDITIONS.md), [upstream exclusion](UPSTREAM-EXCLUSION.md). This fork is not endorsed by upstream.

# VectorPath-RVV — moteur RISC-V RVV / simdjson

Dépôt : https://github.com/MA-Gustave/VectorPath-RVV

**Installation directe :** décompresser le ZIP **VectorPath-RVV_DROP_ROOT_OVERWRITE.zip**
à la racine de ce dépôt. Les répertoires `src/`, `include/`, `scripts/`,
`tests/` et `CMakeLists.txt` doivent être directement au niveau racine.

Cette distribution est une dérivation expérimentale de **simdjson 5.0.3**,
pas une édition officielle de simdjson. Les notices d'origine Apache-2.0 et
MIT sont conservées dans `THIRD_PARTY_LICENSES/` et `LICENSE-MIT`.

La présente distribution **inclut un fichier `LICENSE` à la racine** exposant le périmètre mixte de droits. Les textes historiques Apache/MIT de simdjson restent conservés, sans changement, dans `THIRD_PARTY_LICENSES/` et `LICENSE-MIT`. Les ajouts originaux répondant aux critères restrictifs ne peuvent pas être incorporés dans simdjson officiel sans autorisation signée ; aucune portion existante n'est présentement certifiée comme telle par ces instantanés.

**Release candidate A2 (2026-10-18).** Le profil de compilation du moteur
VectorPath est désormais A2 / 16 Kio / packed désactivé, avec préférence pour le
backend scalable RVV-VLA. Les chemins Stage 2 SIMPLE_RUN et NL4 restent des
options expérimentales désactivées par défaut. Ce correctif concerne VectorPath,
**pas** la copie `engine/` épinglée dans Method Lab. Voir
[le protocole de consolidation](README-VECTORPATH-RELEASE-CANDIDATE.md) et
[les critères de validation finale](docs/VECTORPATH_RC_VALIDATION.md).

L'interface de gestion des expériences se trouve séparément dans
[VLA-MethodLab](https://github.com/MA-Gustave/VLA-MethodLab) ; son dossier
`engine/` peut embarquer une copie antérieure des sources pendant la validation.
Ne pas écraser cette copie sans campagne de synchronisation dédiée.

---

**Licence du dépôt : origine mixte** — [périmètre détaillé](LICENSE-SCOPE.md) ; les licences Apache/MIT ci-dessous ne concernent que le matériel auquel elles s’appliquent.


[![Doxygen Documentation](https://img.shields.io/badge/docs-doxygen-green.svg)](https://simdjson.github.io/simdjson/)

Documentation technique héritée de simdjson (attribution historique, non-endossement)
==============================================================================

simdjson : Parsing gigabytes of JSON per second
===============================================

<img src="images/official_logo/logo_noir/SVG/logo_simdjson_noir.svg" width="40%" style="float: right">

JSON is everywhere on the Internet. Servers spend a *lot* of time parsing it. We need a fresh
approach. The simdjson library uses commonly available SIMD instructions and microparallel algorithms
to parse JSON 4x  faster than RapidJSON and 25x faster than JSON for Modern C++.

* **Fast:** Over 4x faster than commonly used production-grade JSON parsers.
* **Record Breaking Features:** Minify JSON  at 6 GB/s, validate UTF-8  at 13 GB/s,  NDJSON at 3.5 GB/s.
* **Easy:** First-class, easy to use and carefully documented APIs.
* **Strict:** Full JSON and UTF-8 validation, lossless parsing. Performance with no compromises.
* **Automatic:** Selects a CPU-tailored parser at runtime. No configuration needed.
* **Reliable:** From memory allocation to error handling, simdjson's design avoids surprises.
* **Peer Reviewed:** Our research appears in venues like VLDB Journal, Software: Practice and Experience.

This library is part of the [Awesome Modern C++](https://awesomecpp.com) list.

Table of Contents
-----------------

* [Real-world usage](#real-world-usage)
* [Quick Start](#quick-start)
* [Documentation](#documentation)
* [Godbolt](#godbolt)
* [Performance results](#performance-results)
* [Packages](#packages)
* [Bindings and Ports of simdjson](#bindings-and-ports-of-simdjson)
* [About simdjson](#about-simdjson)
* [Funding](#funding)
* [Contributing to simdjson](#contributing-to-simdjson)
* [License](#license)


Real-world usage
----------------

- [Node.js](https://nodejs.org/)
- [ClickHouse](https://github.com/ClickHouse/ClickHouse)
- [Meta Velox](https://velox-lib.io)
- [Google Pax](https://github.com/google/paxml)
- [milvus](https://github.com/milvus-io/milvus)
- [QuestDB](https://questdb.io/blog/questdb-release-8-0-3/)
- [Clang Build Analyzer](https://github.com/aras-p/ClangBuildAnalyzer)
- [Shopify HeapProfiler](https://github.com/Shopify/heap-profiler)
- [StarRocks](https://github.com/StarRocks/starrocks)
- [Microsoft FishStore](https://github.com/microsoft/FishStore)
- [Intel PCM](https://github.com/intel/pcm)
- [WatermelonDB](https://github.com/Nozbe/WatermelonDB)
- [Apache Doris](https://github.com/apache/doris)
- [Dgraph](https://github.com/dgraph-io/dgraph)
- [UCall](https://github.com/unum-cloud/UCall)
- [fastgltf](https://github.com/spnda/fastgltf)
- [tenzir](https://github.com/tenzir/tenzir)
- [ada-url](https://github.com/ada-url/ada)
- [fastgron](https://github.com/adamritter/fastgron)
- [WasmEdge](https://wasmedge.org)
- [RonDB](https://github.com/logicalclocks/rondb)
- [GreptimeDB](https://github.com/GreptimeTeam/greptimedb)
- [mamba](https://github.com/mamba-org/mamba)
- [Ladybird Browser](https://ladybird.org)
- [SereneDB](https://github.com/serenedb/serenedb)
- [YDB](https://github.com/ydb-platform/ydb)
- [ByConity](https://github.com/ByConity/ByConity)
- [Timeplus Proton](https://github.com/timeplus-io/proton)
- [TiFlash](https://github.com/pingcap/tiflash)
- [ata-validator](https://ata-validator.com)

If you are planning to use simdjson in a product, please work from one of our releases.




Quick Start
-----------

The simdjson library is easily consumable with a single .h and .cpp file.

0. Prerequisites: `g++` (version 7 or better) or `clang++` (version 6 or better), and a 64-bit
   system with a command-line shell (e.g., Linux, macOS, freeBSD). We also support programming
   environments like Visual Studio and Xcode, but different steps are needed. Users of clang++ may need to specify the C++ version (e.g., `c++ -std=c++17`) since clang++ tends to default on C++98.
1. Pull [simdjson.h](singleheader/simdjson.h) and [simdjson.cpp](singleheader/simdjson.cpp) into a
   directory, along with the sample file [twitter.json](jsonexamples/twitter.json). You can download them with the `wget` utility:

   ```
   wget https://raw.githubusercontent.com/simdjson/simdjson/master/singleheader/simdjson.h https://raw.githubusercontent.com/simdjson/simdjson/master/singleheader/simdjson.cpp https://raw.githubusercontent.com/simdjson/simdjson/master/jsonexamples/twitter.json
   ```
2. Create `quickstart.cpp`:

```cpp
#include <iostream>
#include "simdjson.h"
using namespace simdjson;
int main(void) {
    ondemand::parser parser;
    padded_string json = padded_string::load("twitter.json");
    ondemand::document tweets = parser.iterate(json);
    std::cout << uint64_t(tweets["search_metadata"]["count"]) << " results." << std::endl;
}
```
3. `c++ -o quickstart quickstart.cpp simdjson.cpp`
4. `./quickstart`

  ```
   100 results.
  ```


Documentation
-------------

Usage documentation is available:

* [Basics](doc/basics.md) is an overview of how to use simdjson and its APIs.
* [Builder](doc/builder.md) is an overview of how to efficiently write JSON strings using simdjson.
* [Performance](doc/performance.md) shows some more advanced scenarios and how to tune for them.
* [Implementation Selection](doc/implementation-selection.md) describes runtime CPU detection and
  how you can work with it.
* [API](https://simdjson.github.io/simdjson/) contains the automatically generated API documentation.
* [Compile-Time Parsing](doc/compile_time.md) presents our compile-time parsing function (C++26 only).


Godbolt
-------------

Some users may want to browse code along with the compiled assembly. The following examples use simdjson 5.0.1:
* [C++26 reflection example](https://godbolt.org/z/zf6Mzn4Kx)
* [simdjson examples with errors handled through exceptions](https://godbolt.org/z/jMcYM43Ed)
* [simdjson examples with errors without exceptions](https://godbolt.org/z/rWMTs68rv)

Performance results
-------------------

The simdjson library uses three-quarters less instructions than state-of-the-art parser [RapidJSON](https://rapidjson.org). To our knowledge, simdjson is the first fully-validating JSON parser
to run at [gigabytes per second](https://en.wikipedia.org/wiki/Gigabyte) (GB/s) on commodity processors. It can parse millions of JSON documents per second on a single core.

The following figures show how fast simdjson maps JSON to and from your own
C++ structs, using C++26 static reflection with GCC 16.2 (-O3). The task is to parse
[twitter.json](jsonexamples/twitter.json) into native data structures and to serialize
them back to JSON, on an Intel Xeon Gold 6548N (Emerald Rapids) processor. We compare
against the fastest C, C++ and Rust libraries, including [Glaze](https://github.com/stephenberry/glaze)
and [Serde](https://serde.rs). The simdjson library offers full unicode ([UTF-8](https://en.wikipedia.org/wiki/UTF-8))
validation and exact number parsing. You can reproduce these results with our
[static reflection benchmarks](benchmark/static_reflect).

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="doc/perf_parsing_twitter_dark.png">
  <img src="doc/perf_parsing_twitter.png" width="80%" alt="Parsing twitter.json into native structs: simdjson 5.11 GB/s, Serde 1.85 GB/s, Glaze 1.67 GB/s, yyjson 1.18 GB/s, RapidJSON 0.85 GB/s, nlohmann::json 0.15 GB/s">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="doc/perf_serialization_twitter_dark.png">
  <img src="doc/perf_serialization_twitter.png" width="80%" alt="Serializing native structs to twitter.json: simdjson 11.2 GB/s, Glaze 6.72 GB/s, Serde 1.85 GB/s, yyjson 1.55 GB/s, reflect-cpp 1.20 GB/s, nlohmann::json 0.19 GB/s">
</picture>

The simdjson library offers high speed whether it processes tiny files (e.g., 300 bytes)
or larger files (e.g., 3MB).

[All our experiments are reproducible](https://github.com/simdjson/simdjson_experiments_vldb2019).


For NDJSON files, we can exceed 3 GB/s with [our  multithreaded parsing functions](https://github.com/simdjson/simdjson/blob/master/doc/parse_many.md).


Packages
------------------------------
[![Packaging status](https://repology.org/badge/vertical-allrepos/simdjson.svg)](https://repology.org/project/simdjson/versions)


Bindings and Ports of simdjson
------------------------------

We distinguish between "bindings" (which just wrap the C++ code) and a port to another programming language (which reimplements everything).

- [ZippyJSON](https://github.com/michaeleisel/zippyjson): Swift bindings for the simdjson project.
- [libpy_simdjson](https://github.com/gerrymanoim/libpy_simdjson/): high-speed Python bindings for simdjson using [libpy](https://github.com/quantopian/libpy).
- [pysimdjson](https://github.com/TkTech/pysimdjson): Python bindings for the simdjson project.
- [cysimdjson](https://github.com/TeskaLabs/cysimdjson): high-speed Python bindings for the simdjson project.
- [fastpysimdjson](https://github.com/simdjson/fastpysimdjson): fast JSON parsing in Python using simdjson.
- [simdjson-rs](https://github.com/simd-lite): Rust port.
- [simdjson-rust](https://github.com/SunDoge/simdjson-rust): Rust wrapper (bindings).
- [SimdJsonSharp](https://github.com/EgorBo/SimdJsonSharp): C# version for .NET Core (bindings and full port).
- [simdjson_nodejs](https://github.com/luizperes/simdjson_nodejs): Node.js bindings for the simdjson project.
- [simdjson_php](https://github.com/crazyxman/simdjson_php): PHP bindings for the simdjson project.
- [simdjson_ruby](https://github.com/saka1/simdjson_ruby): Ruby bindings for the simdjson project.
- [fast_jsonparser](https://github.com/anilmaurya/fast_jsonparser): Ruby bindings for the simdjson project.
- [simdjson-go](https://github.com/minio/simdjson-go): Go port using Golang assembly.
- [rcppsimdjson](https://github.com/eddelbuettel/rcppsimdjson): R bindings.
- [simdjson_erlang](https://github.com/ChomperT/simdjson_erlang): erlang bindings.
- [simdjsone](https://github.com/saleyn/simdjsone): erlang bindings.
- [lua-simdjson](https://github.com/FourierTransformer/lua-simdjson): lua bindings.
- [hermes-json](https://hackage.haskell.org/package/hermes-json): haskell bindings.
- [zimdjson](https://github.com/EzequielRamis/zimdjson): Zig port.
- [simdjzon](https://github.com/travisstaloch/simdjzon): Zig port.
- [JSON-Simd](https://github.com/rawleyfowler/JSON-simd): Raku bindings.
- [JSON::SIMD](https://metacpan.org/pod/JSON::SIMD): Perl bindings; fully-featured JSON module that uses simdjson for decoding.
- [gemmaJSON](https://github.com/sainttttt/gemmaJSON): Nim JSON parser based on simdjson bindings.
- [simdjson-java](https://github.com/simdjson/simdjson-java): Java port.
- [mruby-fast-json](https://github.com/Asmod4n/mruby-fast-json): mruby binding with high API coverage.
- [simdjson-dart](https://github.com/xaldarof/simdjson-dart): Dart bindings for the simdjson project.

About simdjson
--------------

The simdjson library takes advantage of modern microarchitectures, parallelizing with SIMD vector
instructions, reducing branch misprediction, and reducing data dependency to take advantage of each
CPU's multiple execution cores.

Our default front-end is called On-Demand, and we wrote a paper about it:

- John Keiser, Daniel Lemire, [On-Demand JSON: A Better Way to Parse Documents?](https://arxiv.org/abs/2312.17149), Software: Practice and Experience 54 (6), 2024.

Some people [enjoy reading the first (2019) simdjson paper](https://arxiv.org/abs/1902.08318): A description of the design
and implementation of simdjson is in our research article:
- Geoff Langdale, Daniel Lemire, [Parsing Gigabytes of JSON per Second](https://arxiv.org/abs/1902.08318), VLDB Journal 28 (6), 2019.

We have an in-depth paper focused on the UTF-8 validation:

- John Keiser, Daniel Lemire, [Validating UTF-8 In Less Than One Instruction Per Byte](https://arxiv.org/abs/2010.03090), Software: Practice & Experience 51 (5), 2021.

We also have an informal [blog post providing some background and context](https://branchfree.org/2019/02/25/paper-parsing-gigabytes-of-json-per-second/).

For the video inclined, we had a talk at QCon San Francisco 2019<br />
[![simdjson at QCon San Francisco 2019](https://img.youtube.com/vi/wlvKAT7SZIQ/0.jpg)](https://www.youtube.com/watch?v=wlvKAT7SZIQ)<br />
(It was the best voted talk, we're kinda proud of it.)

We also had a CppCon 2025 talk. We show how C++26 reflection allows for one-line serialization (to_json(player)) or deserialization—without invasive macros or manual mapping—using nothing but the C++ standard library. Whether you’re a performance junkie or simply interested in the roadmap for the next decade of C++ development, watch our full talk!

[![simdjson at CppCon 2025](https://img.youtube.com/vi/Mcgk3CxHYMs/0.jpg)](https://www.youtube.com/watch?v=Mcgk3CxHYMs)<br />



Citing this work
-----------------

If you use simdjson in published research, please cite the software library. A suitable BibTeX entry is:

```bibtex
@misc{simdjson,
  title={{The simdjson library: Parsing Gigabytes of JSON per Second}},
  author={Daniel Lemire and Geoff Langdale and John Keiser and Paul Dreik and Francisco Thiesen and others},
  year={2019},
  howpublished={Software library},
  note={https://github.com/simdjson/simdjson}
}
```

Funding
-------

The work is supported by the Natural Sciences and Engineering Research Council of Canada under grants
RGPIN-2017-03910 and RGPIN-2024-03787.

[license]: LICENSE
[license img]: https://img.shields.io/badge/License-Apache%202-blue.svg


[licensemit]: LICENSE-MIT
[licensemit img]: https://img.shields.io/badge/License-MIT-blue.svg


Contributing to simdjson
------------------------

Read [CONTRIBUTING.md](CONTRIBUTING.md) for this independent fork (not for upstream submission), and
[HACKING.md](HACKING.md) for information on source, building, and architecture/design.


License
-------

**Inherited simdjson code** is made available under its original [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0.html) and/or MIT terms, as applicable; already-licensed fork modifications keep their prior grants. **The entire mixed-origin fork is not offered under one blanket licence**. For prospectively verified original additions, consult [LICENSE](LICENSE), [LICENSE-SCOPE.md](LICENSE-SCOPE.md) and [LICENSE-ORIGINAL-ADDITIONS.md](LICENSE-ORIGINAL-ADDITIONS.md). No qualifying reserved additions are yet verified from the supplied snapshots.

Under Windows, we build some tools using the windows/dirent_portable.h file (which is outside our library code): it is under the liberal (business-friendly) MIT license.

For compilers that do not support [C++17](https://en.wikipedia.org/wiki/C%2B%2B17), we bundle the string-view library which is published under the [Boost license](https://www.boost.org/LICENSE_1_0.txt). Like the Apache license, the Boost license is a permissive license allowing commercial redistribution.

For efficient number serialization, we bundle Junekey Jeon's implementation of the Dragonbox algorithm for binary to decimal floating-point numbers (https://github.com/jk-jeon/dragonbox). The Dragonbox implementation is provided under the Apache License Version 2.0 with LLVM Exceptions (LICENSE-Apache2-LLVM or https://llvm.org/foundation/relicensing/LICENSE.txt) or the Boost Software License Version 1.0 (LICENSE-Boost or https://www.boost.org/LICENSE_1_0.txt).

For runtime dispatching, we use some code from the PyTorch project licensed under 3-clause BSD.

## Test 98 public benchmark corpus

See [Test98 dataset and distribution](docs/benchmarks/TEST98_CORPUS_AND_DISTRIBUTION.md) for immutable `simdjson-data` corpus acquisition, SHA256-verified SSH deployment and reproducible official-v5-vs-RVV benchmarks. No external corpus files are committed.
