# Test 103 — Real Stage 2 escape-decoder optimization

State: **completed**; rows: **118560**; phase: **finish**.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_G16384`: unmodified RVV A2, 16 KiB dispatch threshold.
- `A2_SIMPLE_RUN`: A2 with scalar consecutive simple-escape decoding inside Stage 2.
- `A2_NL4`: A2 with the same scalar run and four-pair `\n` burst specialization.
- These are **experimental compile-only overlays**. No production checkout is mutated.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/public_original/public | A2_G16384 | OFFICIAL_504 | 1.5947x | 2.0383x | 1.2657x |
| confirm/public_original/public | A2_NL4 | A2_G16384 | 0.9938x | 0.9975x | 0.9864x |
| confirm/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 0.9972x | 0.9982x | 0.9952x |
| confirm/public_original/public | A2_NL4 | OFFICIAL_504 | 1.5848x | 2.0332x | 1.2484x |
| confirm/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 0.9965x | 0.9993x | 0.9911x |
| confirm/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.5892x | 2.0369x | 1.2544x |
| confirm/synthetic_confirm/crossover | A2_G16384 | OFFICIAL_504 | 6.0910x | 4.9811x | 8.3588x |
| confirm/synthetic_confirm/crossover | A2_NL4 | A2_G16384 | 1.0134x | 0.9901x | 1.0716x |
| confirm/synthetic_confirm/crossover | A2_NL4 | A2_SIMPLE_RUN | 0.9957x | 0.9926x | 1.0096x |
| confirm/synthetic_confirm/crossover | A2_NL4 | OFFICIAL_504 | 6.1728x | 4.9320x | 8.9571x |
| confirm/synthetic_confirm/crossover | A2_SIMPLE_RUN | A2_G16384 | 1.0178x | 0.9975x | 1.0614x |
| confirm/synthetic_confirm/crossover | A2_SIMPLE_RUN | OFFICIAL_504 | 6.1994x | 4.9686x | 8.8720x |
| confirm/synthetic_confirm/mixed | A2_G16384 | OFFICIAL_504 | 2.0257x | 2.6064x | 1.7252x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_G16384 | 1.1389x | 0.9934x | 1.2262x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9790x | 0.9973x | 0.9655x |
| confirm/synthetic_confirm/mixed | A2_NL4 | OFFICIAL_504 | 2.3071x | 2.5891x | 2.1154x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.1634x | 0.9960x | 1.2700x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3566x | 2.5960x | 2.1910x |
| confirm/synthetic_confirm/newline | A2_G16384 | OFFICIAL_504 | 2.0276x | 2.6016x | 1.7323x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_G16384 | 1.1496x | 0.9921x | 1.2672x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_SIMPLE_RUN | 0.9957x | 0.9967x | 1.0149x |
| confirm/synthetic_confirm/newline | A2_NL4 | OFFICIAL_504 | 2.3309x | 2.5810x | 2.1952x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | A2_G16384 | 1.1546x | 0.9954x | 1.2486x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3410x | 2.5895x | 2.1629x |
| confirm/synthetic_confirm/quote | A2_G16384 | OFFICIAL_504 | 2.0369x | 2.5903x | 1.7507x |
| confirm/synthetic_confirm/quote | A2_NL4 | A2_G16384 | 1.1219x | 0.9926x | 1.1903x |
| confirm/synthetic_confirm/quote | A2_NL4 | A2_SIMPLE_RUN | 0.9728x | 0.9959x | 0.9546x |
| confirm/synthetic_confirm/quote | A2_NL4 | OFFICIAL_504 | 2.2853x | 2.5712x | 2.0839x |
| confirm/synthetic_confirm/quote | A2_SIMPLE_RUN | A2_G16384 | 1.1533x | 0.9967x | 1.2470x |
| confirm/synthetic_confirm/quote | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3492x | 2.5817x | 2.1831x |
| confirm/synthetic_confirm/slash | A2_G16384 | OFFICIAL_504 | 1.9022x | 2.3097x | 1.7326x |
| confirm/synthetic_confirm/slash | A2_NL4 | A2_G16384 | 1.1415x | 0.9933x | 1.2245x |
| confirm/synthetic_confirm/slash | A2_NL4 | A2_SIMPLE_RUN | 0.9819x | 0.9984x | 0.9650x |
| confirm/synthetic_confirm/slash | A2_NL4 | OFFICIAL_504 | 2.1713x | 2.2943x | 2.1217x |
| confirm/synthetic_confirm/slash | A2_SIMPLE_RUN | A2_G16384 | 1.1625x | 0.9949x | 1.2689x |
| confirm/synthetic_confirm/slash | A2_SIMPLE_RUN | OFFICIAL_504 | 2.2114x | 2.2981x | 2.1986x |
| confirm/synthetic_confirm/unicode | A2_G16384 | OFFICIAL_504 | 2.1563x | 2.4200x | 1.9485x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_G16384 | 0.9770x | 0.9940x | 0.9605x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9813x | 0.9999x | 0.9633x |
| confirm/synthetic_confirm/unicode | A2_NL4 | OFFICIAL_504 | 2.1066x | 2.4055x | 1.8715x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | A2_G16384 | 0.9955x | 0.9941x | 0.9971x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.1467x | 2.4056x | 1.9428x |
| explore/public_original/public | A2_G16384 | OFFICIAL_504 | 1.6040x | 2.0369x | 1.2771x |
| explore/public_original/public | A2_NL4 | A2_G16384 | 0.9930x | 0.9979x | 0.9858x |
| explore/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 0.9966x | 0.9984x | 0.9950x |
| explore/public_original/public | A2_NL4 | OFFICIAL_504 | 1.5927x | 2.0326x | 1.2589x |
| explore/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 0.9964x | 0.9995x | 0.9907x |
| explore/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.5982x | 2.0359x | 1.2653x |
| explore/synthetic_explore/crossover | A2_G16384 | OFFICIAL_504 | 6.0899x | 4.9814x | 8.3527x |
| explore/synthetic_explore/crossover | A2_NL4 | A2_G16384 | 1.0134x | 0.9900x | 1.0717x |
| explore/synthetic_explore/crossover | A2_NL4 | A2_SIMPLE_RUN | 0.9953x | 0.9924x | 1.0087x |
| explore/synthetic_explore/crossover | A2_NL4 | OFFICIAL_504 | 6.1717x | 4.9315x | 8.9515x |
| explore/synthetic_explore/crossover | A2_SIMPLE_RUN | A2_G16384 | 1.0182x | 0.9975x | 1.0624x |
| explore/synthetic_explore/crossover | A2_SIMPLE_RUN | OFFICIAL_504 | 6.2009x | 4.9692x | 8.8740x |
| explore/synthetic_explore/mixed | A2_G16384 | OFFICIAL_504 | 2.0246x | 2.5966x | 1.7276x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_G16384 | 1.1374x | 0.9934x | 1.2247x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9786x | 0.9990x | 0.9651x |
| explore/synthetic_explore/mixed | A2_NL4 | OFFICIAL_504 | 2.3028x | 2.5795x | 2.1157x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.1623x | 0.9944x | 1.2690x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3532x | 2.5820x | 2.1923x |
| explore/synthetic_explore/newline | A2_G16384 | OFFICIAL_504 | 2.0261x | 2.5999x | 1.7323x |
| explore/synthetic_explore/newline | A2_NL4 | A2_G16384 | 1.1506x | 0.9921x | 1.2698x |
| explore/synthetic_explore/newline | A2_NL4 | A2_SIMPLE_RUN | 0.9961x | 0.9962x | 1.0152x |
| explore/synthetic_explore/newline | A2_NL4 | OFFICIAL_504 | 2.3312x | 2.5793x | 2.1998x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | A2_G16384 | 1.1551x | 0.9958x | 1.2509x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3403x | 2.5891x | 2.1669x |
| explore/synthetic_explore/quote | A2_G16384 | OFFICIAL_504 | 2.0446x | 2.6001x | 1.7529x |
| explore/synthetic_explore/quote | A2_NL4 | A2_G16384 | 1.1225x | 0.9930x | 1.1941x |
| explore/synthetic_explore/quote | A2_NL4 | A2_SIMPLE_RUN | 0.9749x | 0.9970x | 0.9572x |
| explore/synthetic_explore/quote | A2_NL4 | OFFICIAL_504 | 2.2951x | 2.5819x | 2.0931x |
| explore/synthetic_explore/quote | A2_SIMPLE_RUN | A2_G16384 | 1.1514x | 0.9960x | 1.2476x |
| explore/synthetic_explore/quote | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3542x | 2.5895x | 2.1868x |
| explore/synthetic_explore/slash | A2_G16384 | OFFICIAL_504 | 1.8834x | 2.2765x | 1.7293x |
| explore/synthetic_explore/slash | A2_NL4 | A2_G16384 | 1.1427x | 0.9942x | 1.2273x |
| explore/synthetic_explore/slash | A2_NL4 | A2_SIMPLE_RUN | 0.9807x | 0.9981x | 0.9640x |
| explore/synthetic_explore/slash | A2_NL4 | OFFICIAL_504 | 2.1521x | 2.2632x | 2.1224x |
| explore/synthetic_explore/slash | A2_SIMPLE_RUN | A2_G16384 | 1.1652x | 0.9961x | 1.2731x |
| explore/synthetic_explore/slash | A2_SIMPLE_RUN | OFFICIAL_504 | 2.1945x | 2.2676x | 2.2016x |
| explore/synthetic_explore/unicode | A2_G16384 | OFFICIAL_504 | 2.1559x | 2.4189x | 1.9482x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_G16384 | 0.9781x | 0.9946x | 0.9623x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9807x | 0.9987x | 0.9637x |
| explore/synthetic_explore/unicode | A2_NL4 | OFFICIAL_504 | 2.1087x | 2.4059x | 1.8748x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | A2_G16384 | 0.9974x | 0.9959x | 0.9985x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.1502x | 2.4091x | 1.9454x |

## Density sweep and crossover

The exact density and crossover breakdown is in `summary103.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
