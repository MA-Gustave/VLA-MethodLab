# Test 104 — Independent External JSON Validation and Performance

State: **completed**; rows: **282884**; phase: **finish**.

## Official JSONTestSuite conformance

See `conformance104.json` and `conformance104.csv` (all y_/n_/i_/transform cases; i_ unscored).
Conformance failures are **not** silently accepted: `production_promotion_eligible` remains false when any expected-label or cross-variant discrepancy is detected.
Failed expected labels and cross-variant differences are reported, NEVER concealed by excluding from performance.
Official y_ performance results are reported separately from original public simdjson-data and synthetic probes.
- Small y_ fixtures have substantial timing overhead; use primarily for correctness, not headline speedup.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_G16384`: unmodified RVV A2, 16 KiB dispatch threshold.
- `A2_SIMPLE_RUN`: A2 with scalar consecutive simple-escape decoding inside Stage 2.
- `A2_NL4`: A2 with the same scalar run and four-pair `\n` burst specialization.
- These are **experimental compile-only overlays**. No production checkout is mutated.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/jsonsuite_valid/official_y | A2_G16384 | OFFICIAL_504 | 0.6591x | 0.6576x | 0.9134x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | A2_G16384 | 0.9973x | 0.9977x | 1.0003x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | A2_SIMPLE_RUN | 0.9888x | 1.0112x | 1.0033x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | OFFICIAL_504 | 0.6573x | 0.6561x | 0.9138x |
| confirm/jsonsuite_valid/official_y | A2_SIMPLE_RUN | A2_G16384 | 1.0086x | 0.9866x | 0.9971x |
| confirm/jsonsuite_valid/official_y | A2_SIMPLE_RUN | OFFICIAL_504 | 0.6648x | 0.6488x | 0.9108x |
| confirm/public_original/public | A2_G16384 | OFFICIAL_504 | 1.5945x | 2.0379x | 1.2656x |
| confirm/public_original/public | A2_NL4 | A2_G16384 | 0.9932x | 0.9978x | 0.9867x |
| confirm/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 0.9962x | 0.9988x | 0.9949x |
| confirm/public_original/public | A2_NL4 | OFFICIAL_504 | 1.5837x | 2.0335x | 1.2488x |
| confirm/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 0.9970x | 0.9991x | 0.9918x |
| confirm/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.5897x | 2.0360x | 1.2553x |
| confirm/synthetic_confirm/mixed | A2_G16384 | OFFICIAL_504 | 1.4728x | 2.2519x | 1.1586x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_G16384 | 1.3300x | 0.9939x | 1.5791x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9912x | 0.9983x | 0.9961x |
| confirm/synthetic_confirm/mixed | A2_NL4 | OFFICIAL_504 | 1.9587x | 2.2382x | 1.8295x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.3418x | 0.9956x | 1.5853x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9761x | 2.2421x | 1.8367x |
| confirm/synthetic_confirm/newline | A2_G16384 | OFFICIAL_504 | 1.4770x | 2.2465x | 1.1709x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_G16384 | 1.3659x | 0.9923x | 1.7092x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0345x | 0.9965x | 1.1139x |
| confirm/synthetic_confirm/newline | A2_NL4 | OFFICIAL_504 | 2.0174x | 2.2293x | 2.0013x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | A2_G16384 | 1.3204x | 0.9958x | 1.5344x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9502x | 2.2371x | 1.7966x |
| confirm/synthetic_confirm/unicode | A2_G16384 | OFFICIAL_504 | 1.8987x | 2.0651x | 1.8254x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_G16384 | 0.9712x | 0.9950x | 0.9447x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9738x | 0.9982x | 0.9460x |
| confirm/synthetic_confirm/unicode | A2_NL4 | OFFICIAL_504 | 1.8440x | 2.0548x | 1.7246x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | A2_G16384 | 0.9973x | 0.9968x | 0.9986x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 1.8936x | 2.0584x | 1.8230x |
| explore/jsonsuite_valid/official_y | A2_G16384 | OFFICIAL_504 | 0.6593x | 0.6574x | 0.9136x |
| explore/jsonsuite_valid/official_y | A2_NL4 | A2_G16384 | 0.9976x | 0.9982x | 1.0009x |
| explore/jsonsuite_valid/official_y | A2_NL4 | A2_SIMPLE_RUN | 0.9894x | 1.0120x | 1.0041x |
| explore/jsonsuite_valid/official_y | A2_NL4 | OFFICIAL_504 | 0.6577x | 0.6563x | 0.9144x |
| explore/jsonsuite_valid/official_y | A2_SIMPLE_RUN | A2_G16384 | 1.0083x | 0.9863x | 0.9969x |
| explore/jsonsuite_valid/official_y | A2_SIMPLE_RUN | OFFICIAL_504 | 0.6648x | 0.6484x | 0.9107x |
| explore/public_original/public | A2_G16384 | OFFICIAL_504 | 1.5959x | 2.0378x | 1.2661x |
| explore/public_original/public | A2_NL4 | A2_G16384 | 0.9935x | 0.9975x | 0.9872x |
| explore/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 0.9964x | 0.9985x | 0.9951x |
| explore/public_original/public | A2_NL4 | OFFICIAL_504 | 1.5855x | 2.0327x | 1.2499x |
| explore/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 0.9971x | 0.9989x | 0.9920x |
| explore/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.5912x | 2.0357x | 1.2560x |
| explore/synthetic_explore/mixed | A2_G16384 | OFFICIAL_504 | 1.4691x | 2.2390x | 1.1588x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_G16384 | 1.3297x | 0.9936x | 1.5794x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9932x | 0.9991x | 0.9977x |
| explore/synthetic_explore/mixed | A2_NL4 | OFFICIAL_504 | 1.9535x | 2.2247x | 1.8302x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.3388x | 0.9945x | 1.5829x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9669x | 2.2267x | 1.8343x |
| explore/synthetic_explore/newline | A2_G16384 | OFFICIAL_504 | 1.4758x | 2.2435x | 1.1714x |
| explore/synthetic_explore/newline | A2_NL4 | A2_G16384 | 1.3649x | 0.9915x | 1.7088x |
| explore/synthetic_explore/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0348x | 0.9972x | 1.1150x |
| explore/synthetic_explore/newline | A2_NL4 | OFFICIAL_504 | 2.0144x | 2.2243x | 2.0017x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | A2_G16384 | 1.3190x | 0.9943x | 1.5325x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9466x | 2.2306x | 1.7952x |
| explore/synthetic_explore/unicode | A2_G16384 | OFFICIAL_504 | 1.8966x | 2.0663x | 1.8234x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_G16384 | 0.9710x | 0.9949x | 0.9443x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9734x | 0.9984x | 0.9456x |
| explore/synthetic_explore/unicode | A2_NL4 | OFFICIAL_504 | 1.8416x | 2.0558x | 1.7219x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | A2_G16384 | 0.9976x | 0.9965x | 0.9986x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 1.8920x | 2.0591x | 1.8208x |

## Density sweep and crossover

The exact density and crossover breakdown is in `summary104.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
