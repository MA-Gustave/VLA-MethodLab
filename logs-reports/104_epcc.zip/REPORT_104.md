# Test 104 — Independent External JSON Validation and Performance

State: **completed**; rows: **230376**; phase: **finish**.

## Official JSONTestSuite conformance

See `conformance104.json` and `conformance104.csv` (all y_/n_/i_/transform cases; i_ unscored).
Conformance failures are **not** silently accepted: `production_promotion_eligible` remains false when any expected-label or cross-variant discrepancy is detected.
Failed expected labels and cross-variant differences are reported, NEVER concealed by excluding from performance.
Official y_ performance results are reported separately from original public simdjson-data and synthetic probes.
- Small y_ fixtures have substantial timing overhead; use primarily for correctness, not headline speedup.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_G16384`: unmodified RVV A2, 16 KiB dispatch threshold.
- `A2_SIMPLE_RUN`: A2 with scalar consecutive simple-escape decoding inside Stage 2.
- `A2_NL4`: A2 with the same scalar run and four-pair `\n` burst specialization.
- These are **experimental compile-only overlays**. No production checkout is mutated.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/jsonsuite_valid/official_y | A2_G16384 | OFFICIAL_504 | 0.8501x | 0.8501x | 0.9158x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | A2_G16384 | 0.9970x | 0.9994x | 1.0139x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | A2_SIMPLE_RUN | 1.0004x | 1.0000x | 1.0001x |
| confirm/jsonsuite_valid/official_y | A2_NL4 | OFFICIAL_504 | 0.8475x | 0.8496x | 0.9286x |
| confirm/jsonsuite_valid/official_y | A2_SIMPLE_RUN | A2_G16384 | 0.9966x | 0.9994x | 1.0138x |
| confirm/jsonsuite_valid/official_y | A2_SIMPLE_RUN | OFFICIAL_504 | 0.8472x | 0.8497x | 0.9285x |
| confirm/public_original/public | A2_G16384 | OFFICIAL_504 | 1.8944x | 2.5042x | 1.4694x |
| confirm/public_original/public | A2_NL4 | A2_G16384 | 1.0030x | 0.9998x | 1.0070x |
| confirm/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 0.9998x | 0.9990x | 1.0015x |
| confirm/public_original/public | A2_NL4 | OFFICIAL_504 | 1.9000x | 2.5036x | 1.4797x |
| confirm/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 1.0032x | 1.0008x | 1.0055x |
| confirm/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9004x | 2.5062x | 1.4774x |
| confirm/synthetic_confirm/mixed | A2_G16384 | OFFICIAL_504 | 1.7629x | 2.8659x | 1.3182x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_G16384 | 1.3813x | 0.9973x | 1.6318x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9935x | 0.9940x | 0.9926x |
| confirm/synthetic_confirm/mixed | A2_NL4 | OFFICIAL_504 | 2.4351x | 2.8581x | 2.1510x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.3903x | 1.0032x | 1.6440x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.4510x | 2.8752x | 2.1671x |
| confirm/synthetic_confirm/newline | A2_G16384 | OFFICIAL_504 | 1.7707x | 2.8631x | 1.3432x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_G16384 | 1.4633x | 0.9970x | 1.8876x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0588x | 0.9938x | 1.1692x |
| confirm/synthetic_confirm/newline | A2_NL4 | OFFICIAL_504 | 2.5910x | 2.8546x | 2.5354x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | A2_G16384 | 1.3820x | 1.0032x | 1.6144x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.4472x | 2.8723x | 2.1684x |
| confirm/synthetic_confirm/unicode | A2_G16384 | OFFICIAL_504 | 2.3182x | 2.7639x | 1.8329x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_G16384 | 0.9983x | 0.9985x | 0.9952x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9982x | 0.9947x | 0.9998x |
| confirm/synthetic_confirm/unicode | A2_NL4 | OFFICIAL_504 | 2.3142x | 2.7599x | 1.8241x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | A2_G16384 | 1.0000x | 1.0039x | 0.9954x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3183x | 2.7747x | 1.8244x |
| explore/jsonsuite_valid/official_y | A2_G16384 | OFFICIAL_504 | 0.8499x | 0.8498x | 0.9156x |
| explore/jsonsuite_valid/official_y | A2_NL4 | A2_G16384 | 0.9976x | 1.0001x | 1.0146x |
| explore/jsonsuite_valid/official_y | A2_NL4 | A2_SIMPLE_RUN | 1.0006x | 1.0001x | 1.0007x |
| explore/jsonsuite_valid/official_y | A2_NL4 | OFFICIAL_504 | 0.8479x | 0.8499x | 0.9290x |
| explore/jsonsuite_valid/official_y | A2_SIMPLE_RUN | A2_G16384 | 0.9970x | 1.0000x | 1.0139x |
| explore/jsonsuite_valid/official_y | A2_SIMPLE_RUN | OFFICIAL_504 | 0.8474x | 0.8498x | 0.9283x |
| explore/public_original/public | A2_G16384 | OFFICIAL_504 | 1.8940x | 2.5035x | 1.4681x |
| explore/public_original/public | A2_NL4 | A2_G16384 | 1.0031x | 0.9998x | 1.0067x |
| explore/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 1.0000x | 0.9988x | 1.0009x |
| explore/public_original/public | A2_NL4 | OFFICIAL_504 | 1.8999x | 2.5029x | 1.4779x |
| explore/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 1.0032x | 1.0010x | 1.0057x |
| explore/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.9000x | 2.5059x | 1.4766x |
| explore/synthetic_explore/mixed | A2_G16384 | OFFICIAL_504 | 1.7630x | 2.8603x | 1.3205x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_G16384 | 1.3818x | 0.9974x | 1.6308x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9939x | 0.9941x | 0.9922x |
| explore/synthetic_explore/mixed | A2_NL4 | OFFICIAL_504 | 2.4361x | 2.8529x | 2.1535x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.3903x | 1.0034x | 1.6437x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.4511x | 2.8699x | 2.1705x |
| explore/synthetic_explore/newline | A2_G16384 | OFFICIAL_504 | 1.7680x | 2.8654x | 1.3375x |
| explore/synthetic_explore/newline | A2_NL4 | A2_G16384 | 1.4624x | 0.9973x | 1.8885x |
| explore/synthetic_explore/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0579x | 0.9939x | 1.1699x |
| explore/synthetic_explore/newline | A2_NL4 | OFFICIAL_504 | 2.5855x | 2.8577x | 2.5259x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | A2_G16384 | 1.3823x | 1.0034x | 1.6142x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.4439x | 2.8752x | 2.1591x |
| explore/synthetic_explore/unicode | A2_G16384 | OFFICIAL_504 | 2.3212x | 2.7658x | 1.8351x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_G16384 | 0.9980x | 0.9986x | 0.9944x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9987x | 0.9948x | 1.0008x |
| explore/synthetic_explore/unicode | A2_NL4 | OFFICIAL_504 | 2.3166x | 2.7620x | 1.8249x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | A2_G16384 | 0.9993x | 1.0038x | 0.9936x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.3197x | 2.7765x | 1.8234x |

## Density sweep and crossover

The exact density and crossover breakdown is in `summary104.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
