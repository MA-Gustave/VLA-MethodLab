# Test 102 — Overnight escape-density stage attribution

State: **completed**; rows: **83562**; last phase: **finish**.

## Experimental design

- Official simdjson 5.0.4 uses **fallback**; A2 uses the dedicated **RVV** backend.
- Stage 1, Stage 2 and public DOM are measured from actual internal calls, **independently**.
- Stage throughputs are NOT additive and should not be mistaken for contribution percentages.
- Explore and confirm use independent synthetic seeds, but the 18 public fixtures are reused.
- Sparse/dense switching and Stage 2 decoding are hypotheses, not experimentally established causes.
- Packed optimizations are OFF; neither source code nor production thresholds are changed.
- Synthetic escape densities include pathological 50% raw backslash stress; not a representative JSON workload.
- EPCC/Cloud-V results must be analyzed separately; repeated timings are not independent source documents.

## Paired per-document geometric mean (A2 16 KiB / comparator)

| Phase / stratum / family | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/public_original/public | A2_REF | 1.007x | 1.012x | 1.001x |
| confirm/public_original/public | OFFICIAL_504 | 1.892x | 2.505x | 1.467x |
| confirm/synthetic_confirm/crossover | A2_REF | 1.192x | 1.287x | 0.999x |
| confirm/synthetic_confirm/crossover | OFFICIAL_504 | 7.830x | 6.853x | 9.379x |
| confirm/synthetic_confirm/mixed | A2_REF | 1.060x | 1.116x | 1.002x |
| confirm/synthetic_confirm/mixed | OFFICIAL_504 | 2.479x | 3.299x | 2.058x |
| confirm/synthetic_confirm/newline | A2_REF | 1.059x | 1.114x | 1.000x |
| confirm/synthetic_confirm/newline | OFFICIAL_504 | 2.475x | 3.291x | 2.068x |
| confirm/synthetic_confirm/quote | A2_REF | 1.061x | 1.116x | 1.001x |
| confirm/synthetic_confirm/quote | OFFICIAL_504 | 2.520x | 3.296x | 2.126x |
| confirm/synthetic_confirm/slash | A2_REF | 1.057x | 1.104x | 1.000x |
| confirm/synthetic_confirm/slash | OFFICIAL_504 | 2.364x | 3.013x | 2.064x |
| confirm/synthetic_confirm/unicode | A2_REF | 1.062x | 1.111x | 1.000x |
| confirm/synthetic_confirm/unicode | OFFICIAL_504 | 2.636x | 3.163x | 2.096x |
| explore/public_original/public | A2_REF | 1.007x | 1.012x | 1.001x |
| explore/public_original/public | OFFICIAL_504 | 1.894x | 2.504x | 1.469x |
| explore/synthetic_explore/crossover | A2_REF | 1.191x | 1.287x | 0.999x |
| explore/synthetic_explore/crossover | OFFICIAL_504 | 7.831x | 6.854x | 9.379x |
| explore/synthetic_explore/mixed | A2_REF | 1.061x | 1.117x | 1.001x |
| explore/synthetic_explore/mixed | OFFICIAL_504 | 2.479x | 3.295x | 2.058x |
| explore/synthetic_explore/newline | A2_REF | 1.060x | 1.115x | 1.001x |
| explore/synthetic_explore/newline | OFFICIAL_504 | 2.476x | 3.297x | 2.065x |
| explore/synthetic_explore/quote | A2_REF | 1.061x | 1.116x | 1.001x |
| explore/synthetic_explore/quote | OFFICIAL_504 | 2.517x | 3.296x | 2.122x |
| explore/synthetic_explore/slash | A2_REF | 1.057x | 1.105x | 1.000x |
| explore/synthetic_explore/slash | OFFICIAL_504 | 2.353x | 2.985x | 2.070x |
| explore/synthetic_explore/unicode | A2_REF | 1.062x | 1.111x | 0.999x |
| explore/synthetic_explore/unicode | OFFICIAL_504 | 2.635x | 3.162x | 2.094x |

## Controlled density sweep (each phase separate)

| Phase / family / requested raw backslash % | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/synthetic_confirm/mixed/requested_0pct | A2_REF | 1.138x | 1.217x | 1.004x |
| confirm/synthetic_confirm/mixed/requested_0pct | OFFICIAL_504 | 8.123x | 6.925x | 10.569x |
| confirm/synthetic_confirm/mixed/requested_10pct | A2_REF | 1.039x | 1.087x | 1.001x |
| confirm/synthetic_confirm/mixed/requested_10pct | OFFICIAL_504 | 2.197x | 2.768x | 1.721x |
| confirm/synthetic_confirm/mixed/requested_15pct | A2_REF | 1.030x | 1.075x | 1.001x |
| confirm/synthetic_confirm/mixed/requested_15pct | OFFICIAL_504 | 1.623x | 2.297x | 1.175x |
| confirm/synthetic_confirm/mixed/requested_1pct | A2_REF | 1.114x | 1.175x | 1.005x |
| confirm/synthetic_confirm/mixed/requested_1pct | OFFICIAL_504 | 6.345x | 5.646x | 7.291x |
| confirm/synthetic_confirm/mixed/requested_25pct | A2_REF | 1.021x | 1.071x | 1.000x |
| confirm/synthetic_confirm/mixed/requested_25pct | OFFICIAL_504 | 1.171x | 2.203x | 0.733x |
| confirm/synthetic_confirm/mixed/requested_3pct | A2_REF | 1.080x | 1.137x | 1.003x |
| confirm/synthetic_confirm/mixed/requested_3pct | OFFICIAL_504 | 4.557x | 4.522x | 4.575x |
| confirm/synthetic_confirm/mixed/requested_50pct | A2_REF | 1.011x | 1.063x | 1.000x |
| confirm/synthetic_confirm/mixed/requested_50pct | OFFICIAL_504 | 0.463x | 1.600x | 0.228x |
| confirm/synthetic_confirm/mixed/requested_6pct | A2_REF | 1.055x | 1.109x | 1.001x |
| confirm/synthetic_confirm/mixed/requested_6pct | OFFICIAL_504 | 3.139x | 3.545x | 2.699x |
| confirm/synthetic_confirm/newline/requested_0pct | A2_REF | 1.135x | 1.209x | 0.997x |
| confirm/synthetic_confirm/newline/requested_0pct | OFFICIAL_504 | 8.080x | 6.885x | 10.499x |
| confirm/synthetic_confirm/newline/requested_10pct | A2_REF | 1.040x | 1.087x | 0.998x |
| confirm/synthetic_confirm/newline/requested_10pct | OFFICIAL_504 | 2.194x | 2.759x | 1.722x |
| confirm/synthetic_confirm/newline/requested_15pct | A2_REF | 1.029x | 1.074x | 0.999x |
| confirm/synthetic_confirm/newline/requested_15pct | OFFICIAL_504 | 1.614x | 2.295x | 1.167x |
| confirm/synthetic_confirm/newline/requested_1pct | A2_REF | 1.113x | 1.170x | 1.001x |
| confirm/synthetic_confirm/newline/requested_1pct | OFFICIAL_504 | 6.343x | 5.629x | 7.317x |
| confirm/synthetic_confirm/newline/requested_25pct | A2_REF | 1.022x | 1.072x | 1.001x |
| confirm/synthetic_confirm/newline/requested_25pct | OFFICIAL_504 | 1.169x | 2.202x | 0.737x |
| confirm/synthetic_confirm/newline/requested_3pct | A2_REF | 1.077x | 1.137x | 1.002x |
| confirm/synthetic_confirm/newline/requested_3pct | OFFICIAL_504 | 4.514x | 4.510x | 4.534x |
| confirm/synthetic_confirm/newline/requested_50pct | A2_REF | 1.011x | 1.064x | 1.000x |
| confirm/synthetic_confirm/newline/requested_50pct | OFFICIAL_504 | 0.471x | 1.599x | 0.243x |
| confirm/synthetic_confirm/newline/requested_6pct | A2_REF | 1.055x | 1.110x | 0.998x |
| confirm/synthetic_confirm/newline/requested_6pct | OFFICIAL_504 | 3.116x | 3.527x | 2.675x |
| confirm/synthetic_confirm/quote/requested_0pct | A2_REF | 1.142x | 1.215x | 1.003x |
| confirm/synthetic_confirm/quote/requested_0pct | OFFICIAL_504 | 8.152x | 6.920x | 10.543x |
| confirm/synthetic_confirm/quote/requested_10pct | A2_REF | 1.041x | 1.088x | 1.000x |
| confirm/synthetic_confirm/quote/requested_10pct | OFFICIAL_504 | 2.255x | 2.779x | 1.805x |
| confirm/synthetic_confirm/quote/requested_15pct | A2_REF | 1.030x | 1.076x | 1.001x |
| confirm/synthetic_confirm/quote/requested_15pct | OFFICIAL_504 | 1.661x | 2.314x | 1.218x |
| confirm/synthetic_confirm/quote/requested_1pct | A2_REF | 1.116x | 1.177x | 1.001x |
| confirm/synthetic_confirm/quote/requested_1pct | OFFICIAL_504 | 6.358x | 5.637x | 7.328x |
| confirm/synthetic_confirm/quote/requested_25pct | A2_REF | 1.021x | 1.069x | 1.000x |
| confirm/synthetic_confirm/quote/requested_25pct | OFFICIAL_504 | 1.199x | 2.197x | 0.764x |
| confirm/synthetic_confirm/quote/requested_3pct | A2_REF | 1.079x | 1.140x | 1.002x |
| confirm/synthetic_confirm/quote/requested_3pct | OFFICIAL_504 | 4.531x | 4.478x | 4.588x |
| confirm/synthetic_confirm/quote/requested_50pct | A2_REF | 1.011x | 1.064x | 1.000x |
| confirm/synthetic_confirm/quote/requested_50pct | OFFICIAL_504 | 0.486x | 1.598x | 0.252x |
| confirm/synthetic_confirm/quote/requested_6pct | A2_REF | 1.057x | 1.111x | 1.000x |
| confirm/synthetic_confirm/quote/requested_6pct | OFFICIAL_504 | 3.174x | 3.534x | 2.781x |
| confirm/synthetic_confirm/slash/requested_0pct | A2_REF | 1.135x | 1.214x | 1.001x |
| confirm/synthetic_confirm/slash/requested_0pct | OFFICIAL_504 | 8.113x | 6.908x | 10.544x |
| confirm/synthetic_confirm/slash/requested_10pct | A2_REF | 1.035x | 1.072x | 1.000x |
| confirm/synthetic_confirm/slash/requested_10pct | OFFICIAL_504 | 2.001x | 2.298x | 1.710x |
| confirm/synthetic_confirm/slash/requested_15pct | A2_REF | 1.027x | 1.066x | 0.999x |
| confirm/synthetic_confirm/slash/requested_15pct | OFFICIAL_504 | 1.593x | 2.186x | 1.176x |
| confirm/synthetic_confirm/slash/requested_1pct | A2_REF | 1.112x | 1.161x | 0.997x |
| confirm/synthetic_confirm/slash/requested_1pct | OFFICIAL_504 | 6.067x | 5.223x | 7.401x |
| confirm/synthetic_confirm/slash/requested_25pct | A2_REF | 1.020x | 1.067x | 0.999x |
| confirm/synthetic_confirm/slash/requested_25pct | OFFICIAL_504 | 1.172x | 2.197x | 0.733x |
| confirm/synthetic_confirm/slash/requested_3pct | A2_REF | 1.071x | 1.115x | 1.000x |
| confirm/synthetic_confirm/slash/requested_3pct | OFFICIAL_504 | 4.142x | 3.861x | 4.567x |
| confirm/synthetic_confirm/slash/requested_50pct | A2_REF | 1.011x | 1.062x | 1.000x |
| confirm/synthetic_confirm/slash/requested_50pct | OFFICIAL_504 | 0.461x | 1.584x | 0.228x |
| confirm/synthetic_confirm/slash/requested_6pct | A2_REF | 1.049x | 1.086x | 1.000x |
| confirm/synthetic_confirm/slash/requested_6pct | OFFICIAL_504 | 2.775x | 2.790x | 2.750x |
| confirm/synthetic_confirm/unicode/requested_0pct | A2_REF | 1.140x | 1.205x | 1.004x |
| confirm/synthetic_confirm/unicode/requested_0pct | OFFICIAL_504 | 8.160x | 6.878x | 10.529x |
| confirm/synthetic_confirm/unicode/requested_10pct | A2_REF | 1.034x | 1.085x | 1.000x |
| confirm/synthetic_confirm/unicode/requested_10pct | OFFICIAL_504 | 1.736x | 2.649x | 1.120x |
| confirm/synthetic_confirm/unicode/requested_15pct | A2_REF | 1.032x | 1.066x | 1.000x |
| confirm/synthetic_confirm/unicode/requested_15pct | OFFICIAL_504 | 1.297x | 1.949x | 0.800x |
| confirm/synthetic_confirm/unicode/requested_1pct | A2_REF | 1.105x | 1.169x | 0.997x |
| confirm/synthetic_confirm/unicode/requested_1pct | OFFICIAL_504 | 6.016x | 5.666x | 6.453x |
| confirm/synthetic_confirm/unicode/requested_25pct | A2_REF | 1.036x | 1.063x | 1.000x |
| confirm/synthetic_confirm/unicode/requested_25pct | OFFICIAL_504 | 1.425x | 1.784x | 0.975x |
| confirm/synthetic_confirm/unicode/requested_3pct | A2_REF | 1.071x | 1.138x | 0.998x |
| confirm/synthetic_confirm/unicode/requested_3pct | OFFICIAL_504 | 3.974x | 4.488x | 3.390x |
| confirm/synthetic_confirm/unicode/requested_50pct | A2_REF | 1.036x | 1.062x | 1.003x |
| confirm/synthetic_confirm/unicode/requested_50pct | OFFICIAL_504 | 1.430x | 1.784x | 0.979x |
| confirm/synthetic_confirm/unicode/requested_6pct | A2_REF | 1.048x | 1.108x | 1.001x |
| confirm/synthetic_confirm/unicode/requested_6pct | OFFICIAL_504 | 2.605x | 3.483x | 1.891x |
| explore/synthetic_explore/mixed/requested_0pct | A2_REF | 1.139x | 1.218x | 1.006x |
| explore/synthetic_explore/mixed/requested_0pct | OFFICIAL_504 | 8.119x | 6.918x | 10.524x |
| explore/synthetic_explore/mixed/requested_10pct | A2_REF | 1.040x | 1.086x | 0.999x |
| explore/synthetic_explore/mixed/requested_10pct | OFFICIAL_504 | 2.191x | 2.754x | 1.714x |
| explore/synthetic_explore/mixed/requested_15pct | A2_REF | 1.029x | 1.074x | 1.000x |
| explore/synthetic_explore/mixed/requested_15pct | OFFICIAL_504 | 1.625x | 2.301x | 1.174x |
| explore/synthetic_explore/mixed/requested_1pct | A2_REF | 1.114x | 1.175x | 0.999x |
| explore/synthetic_explore/mixed/requested_1pct | OFFICIAL_504 | 6.371x | 5.641x | 7.376x |
| explore/synthetic_explore/mixed/requested_25pct | A2_REF | 1.022x | 1.071x | 1.000x |
| explore/synthetic_explore/mixed/requested_25pct | OFFICIAL_504 | 1.171x | 2.193x | 0.735x |
| explore/synthetic_explore/mixed/requested_3pct | A2_REF | 1.082x | 1.142x | 1.002x |
| explore/synthetic_explore/mixed/requested_3pct | OFFICIAL_504 | 4.548x | 4.526x | 4.543x |
| explore/synthetic_explore/mixed/requested_50pct | A2_REF | 1.011x | 1.064x | 1.000x |
| explore/synthetic_explore/mixed/requested_50pct | OFFICIAL_504 | 0.462x | 1.599x | 0.228x |
| explore/synthetic_explore/mixed/requested_6pct | A2_REF | 1.055x | 1.112x | 1.000x |
| explore/synthetic_explore/mixed/requested_6pct | OFFICIAL_504 | 3.143x | 3.542x | 2.712x |
| explore/synthetic_explore/newline/requested_0pct | A2_REF | 1.136x | 1.215x | 1.007x |
| explore/synthetic_explore/newline/requested_0pct | OFFICIAL_504 | 8.106x | 6.917x | 10.568x |
| explore/synthetic_explore/newline/requested_10pct | A2_REF | 1.042x | 1.086x | 1.001x |
| explore/synthetic_explore/newline/requested_10pct | OFFICIAL_504 | 2.181x | 2.759x | 1.702x |
| explore/synthetic_explore/newline/requested_15pct | A2_REF | 1.029x | 1.073x | 0.999x |
| explore/synthetic_explore/newline/requested_15pct | OFFICIAL_504 | 1.622x | 2.309x | 1.172x |
| explore/synthetic_explore/newline/requested_1pct | A2_REF | 1.112x | 1.176x | 0.997x |
| explore/synthetic_explore/newline/requested_1pct | OFFICIAL_504 | 6.330x | 5.627x | 7.280x |
| explore/synthetic_explore/newline/requested_25pct | A2_REF | 1.021x | 1.071x | 1.000x |
| explore/synthetic_explore/newline/requested_25pct | OFFICIAL_504 | 1.171x | 2.209x | 0.737x |
| explore/synthetic_explore/newline/requested_3pct | A2_REF | 1.080x | 1.138x | 1.001x |
| explore/synthetic_explore/newline/requested_3pct | OFFICIAL_504 | 4.518x | 4.506x | 4.487x |
| explore/synthetic_explore/newline/requested_50pct | A2_REF | 1.010x | 1.064x | 1.000x |
| explore/synthetic_explore/newline/requested_50pct | OFFICIAL_504 | 0.471x | 1.598x | 0.242x |
| explore/synthetic_explore/newline/requested_6pct | A2_REF | 1.054x | 1.110x | 1.001x |
| explore/synthetic_explore/newline/requested_6pct | OFFICIAL_504 | 3.122x | 3.540x | 2.691x |
| explore/synthetic_explore/quote/requested_0pct | A2_REF | 1.136x | 1.215x | 1.004x |
| explore/synthetic_explore/quote/requested_0pct | OFFICIAL_504 | 8.110x | 6.920x | 10.539x |
| explore/synthetic_explore/quote/requested_10pct | A2_REF | 1.041x | 1.090x | 1.000x |
| explore/synthetic_explore/quote/requested_10pct | OFFICIAL_504 | 2.228x | 2.764x | 1.769x |
| explore/synthetic_explore/quote/requested_15pct | A2_REF | 1.030x | 1.074x | 0.999x |
| explore/synthetic_explore/quote/requested_15pct | OFFICIAL_504 | 1.653x | 2.295x | 1.217x |
| explore/synthetic_explore/quote/requested_1pct | A2_REF | 1.115x | 1.173x | 0.998x |
| explore/synthetic_explore/quote/requested_1pct | OFFICIAL_504 | 6.367x | 5.661x | 7.321x |
| explore/synthetic_explore/quote/requested_25pct | A2_REF | 1.021x | 1.072x | 1.000x |
| explore/synthetic_explore/quote/requested_25pct | OFFICIAL_504 | 1.198x | 2.195x | 0.765x |
| explore/synthetic_explore/quote/requested_3pct | A2_REF | 1.081x | 1.141x | 1.001x |
| explore/synthetic_explore/quote/requested_3pct | OFFICIAL_504 | 4.568x | 4.525x | 4.610x |
| explore/synthetic_explore/quote/requested_50pct | A2_REF | 1.011x | 1.065x | 1.001x |
| explore/synthetic_explore/quote/requested_50pct | OFFICIAL_504 | 0.487x | 1.597x | 0.252x |
| explore/synthetic_explore/quote/requested_6pct | A2_REF | 1.057x | 1.111x | 1.001x |
| explore/synthetic_explore/quote/requested_6pct | OFFICIAL_504 | 3.184x | 3.530x | 2.792x |
| explore/synthetic_explore/slash/requested_0pct | A2_REF | 1.139x | 1.215x | 1.004x |
| explore/synthetic_explore/slash/requested_0pct | OFFICIAL_504 | 8.123x | 6.923x | 10.606x |
| explore/synthetic_explore/slash/requested_10pct | A2_REF | 1.035x | 1.069x | 0.999x |
| explore/synthetic_explore/slash/requested_10pct | OFFICIAL_504 | 2.019x | 2.288x | 1.738x |
| explore/synthetic_explore/slash/requested_15pct | A2_REF | 1.027x | 1.065x | 1.000x |
| explore/synthetic_explore/slash/requested_15pct | OFFICIAL_504 | 1.588x | 2.175x | 1.173x |
| explore/synthetic_explore/slash/requested_1pct | A2_REF | 1.114x | 1.165x | 0.995x |
| explore/synthetic_explore/slash/requested_1pct | OFFICIAL_504 | 6.019x | 5.194x | 7.344x |
| explore/synthetic_explore/slash/requested_25pct | A2_REF | 1.021x | 1.069x | 1.000x |
| explore/synthetic_explore/slash/requested_25pct | OFFICIAL_504 | 1.169x | 2.193x | 0.734x |
| explore/synthetic_explore/slash/requested_3pct | A2_REF | 1.072x | 1.119x | 1.000x |
| explore/synthetic_explore/slash/requested_3pct | OFFICIAL_504 | 3.980x | 3.621x | 4.589x |
| explore/synthetic_explore/slash/requested_50pct | A2_REF | 1.010x | 1.064x | 1.000x |
| explore/synthetic_explore/slash/requested_50pct | OFFICIAL_504 | 0.461x | 1.585x | 0.228x |
| explore/synthetic_explore/slash/requested_6pct | A2_REF | 1.049x | 1.087x | 1.000x |
| explore/synthetic_explore/slash/requested_6pct | OFFICIAL_504 | 2.791x | 2.797x | 2.772x |
| explore/synthetic_explore/unicode/requested_0pct | A2_REF | 1.140x | 1.206x | 0.998x |
| explore/synthetic_explore/unicode/requested_0pct | OFFICIAL_504 | 8.171x | 6.889x | 10.524x |
| explore/synthetic_explore/unicode/requested_10pct | A2_REF | 1.034x | 1.085x | 0.999x |
| explore/synthetic_explore/unicode/requested_10pct | OFFICIAL_504 | 1.736x | 2.651x | 1.119x |
| explore/synthetic_explore/unicode/requested_15pct | A2_REF | 1.031x | 1.066x | 1.000x |
| explore/synthetic_explore/unicode/requested_15pct | OFFICIAL_504 | 1.292x | 1.940x | 0.795x |
| explore/synthetic_explore/unicode/requested_1pct | A2_REF | 1.105x | 1.170x | 0.998x |
| explore/synthetic_explore/unicode/requested_1pct | OFFICIAL_504 | 5.981x | 5.648x | 6.380x |
| explore/synthetic_explore/unicode/requested_25pct | A2_REF | 1.035x | 1.062x | 1.000x |
| explore/synthetic_explore/unicode/requested_25pct | OFFICIAL_504 | 1.431x | 1.787x | 0.980x |
| explore/synthetic_explore/unicode/requested_3pct | A2_REF | 1.072x | 1.137x | 1.000x |
| explore/synthetic_explore/unicode/requested_3pct | OFFICIAL_504 | 3.979x | 4.489x | 3.396x |
| explore/synthetic_explore/unicode/requested_50pct | A2_REF | 1.035x | 1.062x | 1.000x |
| explore/synthetic_explore/unicode/requested_50pct | OFFICIAL_504 | 1.428x | 1.786x | 0.978x |
| explore/synthetic_explore/unicode/requested_6pct | A2_REF | 1.049x | 1.111x | 1.000x |
| explore/synthetic_explore/unicode/requested_6pct | OFFICIAL_504 | 2.608x | 3.487x | 1.898x |

## Crossover: backslash count and position

| Phase / count / position | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/synthetic_confirm/crossover/count_0/after512 | A2_REF | 1.199x | 1.293x | 1.000x |
| confirm/synthetic_confirm/crossover/count_0/after512 | OFFICIAL_504 | 8.183x | 6.973x | 10.262x |
| confirm/synthetic_confirm/crossover/count_0/early | A2_REF | 1.205x | 1.293x | 0.999x |
| confirm/synthetic_confirm/crossover/count_0/early | OFFICIAL_504 | 8.252x | 7.013x | 10.366x |
| confirm/synthetic_confirm/crossover/count_1/after512 | A2_REF | 1.198x | 1.292x | 1.000x |
| confirm/synthetic_confirm/crossover/count_1/after512 | OFFICIAL_504 | 8.107x | 6.945x | 10.075x |
| confirm/synthetic_confirm/crossover/count_1/early | A2_REF | 1.197x | 1.291x | 0.999x |
| confirm/synthetic_confirm/crossover/count_1/early | OFFICIAL_504 | 8.098x | 6.950x | 10.041x |
| confirm/synthetic_confirm/crossover/count_12/after512 | A2_REF | 1.190x | 1.286x | 1.000x |
| confirm/synthetic_confirm/crossover/count_12/after512 | OFFICIAL_504 | 7.706x | 6.802x | 9.094x |
| confirm/synthetic_confirm/crossover/count_12/early | A2_REF | 1.188x | 1.283x | 1.000x |
| confirm/synthetic_confirm/crossover/count_12/early | OFFICIAL_504 | 7.703x | 6.805x | 9.072x |
| confirm/synthetic_confirm/crossover/count_16/after512 | A2_REF | 1.186x | 1.285x | 1.000x |
| confirm/synthetic_confirm/crossover/count_16/after512 | OFFICIAL_504 | 7.624x | 6.803x | 8.820x |
| confirm/synthetic_confirm/crossover/count_16/early | A2_REF | 1.184x | 1.284x | 1.000x |
| confirm/synthetic_confirm/crossover/count_16/early | OFFICIAL_504 | 7.619x | 6.803x | 8.794x |
| confirm/synthetic_confirm/crossover/count_2/after512 | A2_REF | 1.199x | 1.291x | 0.999x |
| confirm/synthetic_confirm/crossover/count_2/after512 | OFFICIAL_504 | 8.118x | 6.930x | 10.157x |
| confirm/synthetic_confirm/crossover/count_2/early | A2_REF | 1.195x | 1.291x | 1.000x |
| confirm/synthetic_confirm/crossover/count_2/early | OFFICIAL_504 | 8.058x | 6.937x | 9.966x |
| confirm/synthetic_confirm/crossover/count_32/after512 | A2_REF | 1.176x | 1.283x | 0.998x |
| confirm/synthetic_confirm/crossover/count_32/after512 | OFFICIAL_504 | 7.225x | 6.694x | 7.881x |
| confirm/synthetic_confirm/crossover/count_32/early | A2_REF | 1.176x | 1.277x | 1.000x |
| confirm/synthetic_confirm/crossover/count_32/early | OFFICIAL_504 | 7.170x | 6.661x | 7.818x |
| confirm/synthetic_confirm/crossover/count_4/after512 | A2_REF | 1.195x | 1.289x | 1.000x |
| confirm/synthetic_confirm/crossover/count_4/after512 | OFFICIAL_504 | 7.970x | 6.888x | 9.757x |
| confirm/synthetic_confirm/crossover/count_4/early | A2_REF | 1.195x | 1.289x | 0.998x |
| confirm/synthetic_confirm/crossover/count_4/early | OFFICIAL_504 | 7.985x | 6.897x | 9.761x |
| confirm/synthetic_confirm/crossover/count_8/after512 | A2_REF | 1.194x | 1.288x | 0.999x |
| confirm/synthetic_confirm/crossover/count_8/after512 | OFFICIAL_504 | 7.827x | 6.822x | 9.418x |
| confirm/synthetic_confirm/crossover/count_8/early | A2_REF | 1.190x | 1.288x | 1.000x |
| confirm/synthetic_confirm/crossover/count_8/early | OFFICIAL_504 | 7.832x | 6.831x | 9.403x |
| confirm/synthetic_confirm/crossover/count_9/after512 | A2_REF | 1.192x | 1.285x | 0.999x |
| confirm/synthetic_confirm/crossover/count_9/after512 | OFFICIAL_504 | 7.792x | 6.800x | 9.360x |
| confirm/synthetic_confirm/crossover/count_9/early | A2_REF | 1.189x | 1.285x | 1.000x |
| confirm/synthetic_confirm/crossover/count_9/early | OFFICIAL_504 | 7.777x | 6.808x | 9.299x |
| explore/synthetic_explore/crossover/count_0/after512 | A2_REF | 1.199x | 1.293x | 0.999x |
| explore/synthetic_explore/crossover/count_0/after512 | OFFICIAL_504 | 8.183x | 6.974x | 10.261x |
| explore/synthetic_explore/crossover/count_0/early | A2_REF | 1.204x | 1.293x | 0.996x |
| explore/synthetic_explore/crossover/count_0/early | OFFICIAL_504 | 8.253x | 7.022x | 10.363x |
| explore/synthetic_explore/crossover/count_1/after512 | A2_REF | 1.198x | 1.292x | 1.000x |
| explore/synthetic_explore/crossover/count_1/after512 | OFFICIAL_504 | 8.108x | 6.947x | 10.080x |
| explore/synthetic_explore/crossover/count_1/early | A2_REF | 1.195x | 1.292x | 1.000x |
| explore/synthetic_explore/crossover/count_1/early | OFFICIAL_504 | 8.090x | 6.949x | 10.034x |
| explore/synthetic_explore/crossover/count_12/after512 | A2_REF | 1.190x | 1.285x | 0.999x |
| explore/synthetic_explore/crossover/count_12/after512 | OFFICIAL_504 | 7.706x | 6.801x | 9.092x |
| explore/synthetic_explore/crossover/count_12/early | A2_REF | 1.187x | 1.282x | 0.998x |
| explore/synthetic_explore/crossover/count_12/early | OFFICIAL_504 | 7.707x | 6.799x | 9.060x |
| explore/synthetic_explore/crossover/count_16/after512 | A2_REF | 1.186x | 1.285x | 0.999x |
| explore/synthetic_explore/crossover/count_16/after512 | OFFICIAL_504 | 7.627x | 6.798x | 8.818x |
| explore/synthetic_explore/crossover/count_16/early | A2_REF | 1.185x | 1.284x | 0.999x |
| explore/synthetic_explore/crossover/count_16/early | OFFICIAL_504 | 7.616x | 6.806x | 8.790x |
| explore/synthetic_explore/crossover/count_2/after512 | A2_REF | 1.198x | 1.291x | 1.000x |
| explore/synthetic_explore/crossover/count_2/after512 | OFFICIAL_504 | 8.116x | 6.930x | 10.163x |
| explore/synthetic_explore/crossover/count_2/early | A2_REF | 1.195x | 1.290x | 1.000x |
| explore/synthetic_explore/crossover/count_2/early | OFFICIAL_504 | 8.056x | 6.936x | 9.949x |
| explore/synthetic_explore/crossover/count_32/after512 | A2_REF | 1.176x | 1.285x | 1.000x |
| explore/synthetic_explore/crossover/count_32/after512 | OFFICIAL_504 | 7.227x | 6.706x | 7.894x |
| explore/synthetic_explore/crossover/count_32/early | A2_REF | 1.175x | 1.277x | 0.999x |
| explore/synthetic_explore/crossover/count_32/early | OFFICIAL_504 | 7.171x | 6.658x | 7.817x |
| explore/synthetic_explore/crossover/count_4/after512 | A2_REF | 1.195x | 1.289x | 1.000x |
| explore/synthetic_explore/crossover/count_4/after512 | OFFICIAL_504 | 7.974x | 6.886x | 9.761x |
| explore/synthetic_explore/crossover/count_4/early | A2_REF | 1.194x | 1.290x | 0.999x |
| explore/synthetic_explore/crossover/count_4/early | OFFICIAL_504 | 7.990x | 6.902x | 9.767x |
| explore/synthetic_explore/crossover/count_8/after512 | A2_REF | 1.193x | 1.287x | 0.998x |
| explore/synthetic_explore/crossover/count_8/after512 | OFFICIAL_504 | 7.827x | 6.826x | 9.418x |
| explore/synthetic_explore/crossover/count_8/early | A2_REF | 1.191x | 1.287x | 1.000x |
| explore/synthetic_explore/crossover/count_8/early | OFFICIAL_504 | 7.825x | 6.831x | 9.399x |
| explore/synthetic_explore/crossover/count_9/after512 | A2_REF | 1.191x | 1.285x | 0.999x |
| explore/synthetic_explore/crossover/count_9/after512 | OFFICIAL_504 | 7.802x | 6.803x | 9.376x |
| explore/synthetic_explore/crossover/count_9/early | A2_REF | 1.190x | 1.284x | 0.999x |
| explore/synthetic_explore/crossover/count_9/early | OFFICIAL_504 | 7.779x | 6.803x | 9.296x |

## Decision gate

Look at stage-specific ratios around 8/9 backslashes, across escaped vs public files and explore vs confirm before choosing a Stage 1 or Stage 2 code change.
No automatic promotion. Raw rows: `results102.csv`; input SHA256 and compiler flags are included.
