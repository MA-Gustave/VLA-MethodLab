# Test 102 — Overnight escape-density stage attribution

State: **completed**; rows: **101682**; last phase: **finish**.

## Experimental design

- Official simdjson 5.0.4 uses **fallback**; A2 uses the dedicated **RVV** backend.
- Stage 1, Stage 2 and public DOM are measured from actual internal calls, **independently**.
- Stage throughputs are NOT additive and should not be mistaken for contribution percentages.
- Explore and confirm use independent synthetic seeds, but the 18 public fixtures are reused.
- Sparse/dense switching and Stage 2 decoding are hypotheses, not experimentally established causes.
- Packed optimizations are OFF; neither source code nor production thresholds are changed.
- Synthetic escape densities include pathological 50% raw backslash stress; not a representative JSON workload.
- EPCC/Cloud-V results must be analyzed separately; repeated timings are not independent source documents.

## Paired per-document geometric mean (A2 16 KiB / comparator)

| Phase / stratum / family | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/public_original/public | A2_REF | 1.004x | 1.007x | 1.001x |
| confirm/public_original/public | OFFICIAL_504 | 1.607x | 2.037x | 1.283x |
| confirm/synthetic_confirm/crossover | A2_REF | 1.162x | 1.224x | 0.998x |
| confirm/synthetic_confirm/crossover | OFFICIAL_504 | 6.092x | 4.983x | 8.361x |
| confirm/synthetic_confirm/mixed | A2_REF | 1.048x | 1.087x | 0.998x |
| confirm/synthetic_confirm/mixed | OFFICIAL_504 | 2.027x | 2.603x | 1.723x |
| confirm/synthetic_confirm/newline | A2_REF | 1.049x | 1.088x | 1.001x |
| confirm/synthetic_confirm/newline | OFFICIAL_504 | 2.027x | 2.600x | 1.734x |
| confirm/synthetic_confirm/quote | A2_REF | 1.049x | 1.087x | 1.000x |
| confirm/synthetic_confirm/quote | OFFICIAL_504 | 2.039x | 2.594x | 1.752x |
| confirm/synthetic_confirm/slash | A2_REF | 1.047x | 1.077x | 1.000x |
| confirm/synthetic_confirm/slash | OFFICIAL_504 | 1.902x | 2.305x | 1.731x |
| confirm/synthetic_confirm/unicode | A2_REF | 1.049x | 1.086x | 1.000x |
| confirm/synthetic_confirm/unicode | OFFICIAL_504 | 2.157x | 2.419x | 1.946x |
| explore/public_original/public | A2_REF | 1.004x | 1.008x | 1.000x |
| explore/public_original/public | OFFICIAL_504 | 1.608x | 2.036x | 1.282x |
| explore/synthetic_explore/crossover | A2_REF | 1.162x | 1.224x | 0.999x |
| explore/synthetic_explore/crossover | OFFICIAL_504 | 6.093x | 4.984x | 8.360x |
| explore/synthetic_explore/mixed | A2_REF | 1.050x | 1.087x | 1.002x |
| explore/synthetic_explore/mixed | OFFICIAL_504 | 2.024x | 2.595x | 1.729x |
| explore/synthetic_explore/newline | A2_REF | 1.049x | 1.086x | 0.999x |
| explore/synthetic_explore/newline | OFFICIAL_504 | 2.027x | 2.600x | 1.731x |
| explore/synthetic_explore/quote | A2_REF | 1.050x | 1.088x | 1.000x |
| explore/synthetic_explore/quote | OFFICIAL_504 | 2.043x | 2.602x | 1.752x |
| explore/synthetic_explore/slash | A2_REF | 1.047x | 1.079x | 1.000x |
| explore/synthetic_explore/slash | OFFICIAL_504 | 1.886x | 2.276x | 1.730x |
| explore/synthetic_explore/unicode | A2_REF | 1.049x | 1.087x | 1.000x |
| explore/synthetic_explore/unicode | OFFICIAL_504 | 2.156x | 2.419x | 1.948x |

## Controlled density sweep (each phase separate)

| Phase / family / requested raw backslash % | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/synthetic_confirm/mixed/requested_0pct | A2_REF | 1.111x | 1.152x | 0.991x |
| confirm/synthetic_confirm/mixed/requested_0pct | OFFICIAL_504 | 6.249x | 4.951x | 9.252x |
| confirm/synthetic_confirm/mixed/requested_10pct | A2_REF | 1.031x | 1.070x | 0.998x |
| confirm/synthetic_confirm/mixed/requested_10pct | OFFICIAL_504 | 1.777x | 2.270x | 1.371x |
| confirm/synthetic_confirm/mixed/requested_15pct | A2_REF | 1.022x | 1.050x | 1.000x |
| confirm/synthetic_confirm/mixed/requested_15pct | OFFICIAL_504 | 1.299x | 1.768x | 0.956x |
| confirm/synthetic_confirm/mixed/requested_1pct | A2_REF | 1.093x | 1.143x | 1.001x |
| confirm/synthetic_confirm/mixed/requested_1pct | OFFICIAL_504 | 4.978x | 4.378x | 5.972x |
| confirm/synthetic_confirm/mixed/requested_25pct | A2_REF | 1.014x | 1.044x | 0.999x |
| confirm/synthetic_confirm/mixed/requested_25pct | OFFICIAL_504 | 0.990x | 1.706x | 0.640x |
| confirm/synthetic_confirm/mixed/requested_3pct | A2_REF | 1.066x | 1.113x | 0.999x |
| confirm/synthetic_confirm/mixed/requested_3pct | OFFICIAL_504 | 3.646x | 3.642x | 3.589x |
| confirm/synthetic_confirm/mixed/requested_50pct | A2_REF | 1.007x | 1.037x | 1.000x |
| confirm/synthetic_confirm/mixed/requested_50pct | OFFICIAL_504 | 0.431x | 1.330x | 0.218x |
| confirm/synthetic_confirm/mixed/requested_6pct | A2_REF | 1.044x | 1.092x | 0.998x |
| confirm/synthetic_confirm/mixed/requested_6pct | OFFICIAL_504 | 2.548x | 2.934x | 2.139x |
| confirm/synthetic_confirm/newline/requested_0pct | A2_REF | 1.126x | 1.164x | 1.004x |
| confirm/synthetic_confirm/newline/requested_0pct | OFFICIAL_504 | 6.303x | 5.004x | 9.409x |
| confirm/synthetic_confirm/newline/requested_10pct | A2_REF | 1.030x | 1.066x | 1.002x |
| confirm/synthetic_confirm/newline/requested_10pct | OFFICIAL_504 | 1.766x | 2.255x | 1.366x |
| confirm/synthetic_confirm/newline/requested_15pct | A2_REF | 1.022x | 1.055x | 0.999x |
| confirm/synthetic_confirm/newline/requested_15pct | OFFICIAL_504 | 1.295x | 1.775x | 0.950x |
| confirm/synthetic_confirm/newline/requested_1pct | A2_REF | 1.089x | 1.143x | 1.002x |
| confirm/synthetic_confirm/newline/requested_1pct | OFFICIAL_504 | 4.981x | 4.371x | 6.023x |
| confirm/synthetic_confirm/newline/requested_25pct | A2_REF | 1.015x | 1.044x | 1.000x |
| confirm/synthetic_confirm/newline/requested_25pct | OFFICIAL_504 | 0.986x | 1.691x | 0.640x |
| confirm/synthetic_confirm/newline/requested_3pct | A2_REF | 1.067x | 1.117x | 1.003x |
| confirm/synthetic_confirm/newline/requested_3pct | OFFICIAL_504 | 3.628x | 3.646x | 3.576x |
| confirm/synthetic_confirm/newline/requested_50pct | A2_REF | 1.007x | 1.036x | 1.000x |
| confirm/synthetic_confirm/newline/requested_50pct | OFFICIAL_504 | 0.439x | 1.329x | 0.228x |
| confirm/synthetic_confirm/newline/requested_6pct | A2_REF | 1.046x | 1.090x | 1.000x |
| confirm/synthetic_confirm/newline/requested_6pct | OFFICIAL_504 | 2.527x | 2.917x | 2.125x |
| confirm/synthetic_confirm/quote/requested_0pct | A2_REF | 1.109x | 1.157x | 0.998x |
| confirm/synthetic_confirm/quote/requested_0pct | OFFICIAL_504 | 6.254x | 4.975x | 9.346x |
| confirm/synthetic_confirm/quote/requested_10pct | A2_REF | 1.034x | 1.070x | 1.002x |
| confirm/synthetic_confirm/quote/requested_10pct | OFFICIAL_504 | 1.791x | 2.251x | 1.401x |
| confirm/synthetic_confirm/quote/requested_15pct | A2_REF | 1.021x | 1.053x | 1.000x |
| confirm/synthetic_confirm/quote/requested_15pct | OFFICIAL_504 | 1.315x | 1.780x | 0.975x |
| confirm/synthetic_confirm/quote/requested_1pct | A2_REF | 1.094x | 1.139x | 1.000x |
| confirm/synthetic_confirm/quote/requested_1pct | OFFICIAL_504 | 4.952x | 4.378x | 5.881x |
| confirm/synthetic_confirm/quote/requested_25pct | A2_REF | 1.014x | 1.044x | 1.000x |
| confirm/synthetic_confirm/quote/requested_25pct | OFFICIAL_504 | 1.000x | 1.696x | 0.655x |
| confirm/synthetic_confirm/quote/requested_3pct | A2_REF | 1.070x | 1.119x | 1.002x |
| confirm/synthetic_confirm/quote/requested_3pct | OFFICIAL_504 | 3.599x | 3.578x | 3.572x |
| confirm/synthetic_confirm/quote/requested_50pct | A2_REF | 1.006x | 1.035x | 1.000x |
| confirm/synthetic_confirm/quote/requested_50pct | OFFICIAL_504 | 0.446x | 1.329x | 0.234x |
| confirm/synthetic_confirm/quote/requested_6pct | A2_REF | 1.044x | 1.087x | 0.999x |
| confirm/synthetic_confirm/quote/requested_6pct | OFFICIAL_504 | 2.550x | 2.919x | 2.160x |
| confirm/synthetic_confirm/slash/requested_0pct | A2_REF | 1.116x | 1.153x | 0.993x |
| confirm/synthetic_confirm/slash/requested_0pct | OFFICIAL_504 | 6.279x | 4.975x | 9.357x |
| confirm/synthetic_confirm/slash/requested_10pct | A2_REF | 1.027x | 1.049x | 1.000x |
| confirm/synthetic_confirm/slash/requested_10pct | OFFICIAL_504 | 1.532x | 1.671x | 1.371x |
| confirm/synthetic_confirm/slash/requested_15pct | A2_REF | 1.019x | 1.043x | 1.000x |
| confirm/synthetic_confirm/slash/requested_15pct | OFFICIAL_504 | 1.244x | 1.601x | 0.958x |
| confirm/synthetic_confirm/slash/requested_1pct | A2_REF | 1.098x | 1.136x | 1.005x |
| confirm/synthetic_confirm/slash/requested_1pct | OFFICIAL_504 | 4.793x | 4.086x | 6.122x |
| confirm/synthetic_confirm/slash/requested_25pct | A2_REF | 1.014x | 1.044x | 1.001x |
| confirm/synthetic_confirm/slash/requested_25pct | OFFICIAL_504 | 0.984x | 1.690x | 0.641x |
| confirm/synthetic_confirm/slash/requested_3pct | A2_REF | 1.058x | 1.093x | 0.997x |
| confirm/synthetic_confirm/slash/requested_3pct | OFFICIAL_504 | 3.281x | 3.074x | 3.568x |
| confirm/synthetic_confirm/slash/requested_50pct | A2_REF | 1.006x | 1.036x | 0.999x |
| confirm/synthetic_confirm/slash/requested_50pct | OFFICIAL_504 | 0.431x | 1.329x | 0.219x |
| confirm/synthetic_confirm/slash/requested_6pct | A2_REF | 1.040x | 1.066x | 1.001x |
| confirm/synthetic_confirm/slash/requested_6pct | OFFICIAL_504 | 2.144x | 2.124x | 2.144x |
| confirm/synthetic_confirm/unicode/requested_0pct | A2_REF | 1.117x | 1.156x | 0.997x |
| confirm/synthetic_confirm/unicode/requested_0pct | OFFICIAL_504 | 6.285x | 4.984x | 9.351x |
| confirm/synthetic_confirm/unicode/requested_10pct | A2_REF | 1.027x | 1.071x | 0.999x |
| confirm/synthetic_confirm/unicode/requested_10pct | OFFICIAL_504 | 1.476x | 2.195x | 1.034x |
| confirm/synthetic_confirm/unicode/requested_15pct | A2_REF | 1.020x | 1.047x | 1.001x |
| confirm/synthetic_confirm/unicode/requested_15pct | OFFICIAL_504 | 1.111x | 1.432x | 0.860x |
| confirm/synthetic_confirm/unicode/requested_1pct | A2_REF | 1.090x | 1.141x | 1.003x |
| confirm/synthetic_confirm/unicode/requested_1pct | OFFICIAL_504 | 4.731x | 4.376x | 5.175x |
| confirm/synthetic_confirm/unicode/requested_25pct | A2_REF | 1.022x | 1.039x | 0.997x |
| confirm/synthetic_confirm/unicode/requested_25pct | OFFICIAL_504 | 1.194x | 1.286x | 1.067x |
| confirm/synthetic_confirm/unicode/requested_3pct | A2_REF | 1.061x | 1.115x | 1.002x |
| confirm/synthetic_confirm/unicode/requested_3pct | OFFICIAL_504 | 3.177x | 3.605x | 2.676x |
| confirm/synthetic_confirm/unicode/requested_50pct | A2_REF | 1.022x | 1.040x | 0.999x |
| confirm/synthetic_confirm/unicode/requested_50pct | OFFICIAL_504 | 1.193x | 1.287x | 1.066x |
| confirm/synthetic_confirm/unicode/requested_6pct | A2_REF | 1.039x | 1.090x | 1.002x |
| confirm/synthetic_confirm/unicode/requested_6pct | OFFICIAL_504 | 2.119x | 2.866x | 1.571x |
| explore/synthetic_explore/mixed/requested_0pct | A2_REF | 1.123x | 1.161x | 1.007x |
| explore/synthetic_explore/mixed/requested_0pct | OFFICIAL_504 | 6.295x | 4.995x | 9.392x |
| explore/synthetic_explore/mixed/requested_10pct | A2_REF | 1.032x | 1.066x | 1.002x |
| explore/synthetic_explore/mixed/requested_10pct | OFFICIAL_504 | 1.767x | 2.228x | 1.377x |
| explore/synthetic_explore/mixed/requested_15pct | A2_REF | 1.022x | 1.053x | 0.999x |
| explore/synthetic_explore/mixed/requested_15pct | OFFICIAL_504 | 1.294x | 1.765x | 0.953x |
| explore/synthetic_explore/mixed/requested_1pct | A2_REF | 1.094x | 1.138x | 1.000x |
| explore/synthetic_explore/mixed/requested_1pct | OFFICIAL_504 | 4.998x | 4.360x | 6.048x |
| explore/synthetic_explore/mixed/requested_25pct | A2_REF | 1.014x | 1.043x | 1.000x |
| explore/synthetic_explore/mixed/requested_25pct | OFFICIAL_504 | 0.984x | 1.686x | 0.639x |
| explore/synthetic_explore/mixed/requested_3pct | A2_REF | 1.069x | 1.116x | 1.003x |
| explore/synthetic_explore/mixed/requested_3pct | OFFICIAL_504 | 3.634x | 3.646x | 3.576x |
| explore/synthetic_explore/mixed/requested_50pct | A2_REF | 1.007x | 1.035x | 1.000x |
| explore/synthetic_explore/mixed/requested_50pct | OFFICIAL_504 | 0.431x | 1.330x | 0.218x |
| explore/synthetic_explore/mixed/requested_6pct | A2_REF | 1.046x | 1.090x | 1.003x |
| explore/synthetic_explore/mixed/requested_6pct | OFFICIAL_504 | 2.543x | 2.935x | 2.145x |
| explore/synthetic_explore/newline/requested_0pct | A2_REF | 1.114x | 1.154x | 0.994x |
| explore/synthetic_explore/newline/requested_0pct | OFFICIAL_504 | 6.259x | 4.975x | 9.347x |
| explore/synthetic_explore/newline/requested_10pct | A2_REF | 1.031x | 1.066x | 0.998x |
| explore/synthetic_explore/newline/requested_10pct | OFFICIAL_504 | 1.765x | 2.241x | 1.364x |
| explore/synthetic_explore/newline/requested_15pct | A2_REF | 1.022x | 1.050x | 1.000x |
| explore/synthetic_explore/newline/requested_15pct | OFFICIAL_504 | 1.306x | 1.786x | 0.955x |
| explore/synthetic_explore/newline/requested_1pct | A2_REF | 1.098x | 1.141x | 1.000x |
| explore/synthetic_explore/newline/requested_1pct | OFFICIAL_504 | 4.987x | 4.372x | 6.045x |
| explore/synthetic_explore/newline/requested_25pct | A2_REF | 1.014x | 1.044x | 1.000x |
| explore/synthetic_explore/newline/requested_25pct | OFFICIAL_504 | 0.984x | 1.689x | 0.640x |
| explore/synthetic_explore/newline/requested_3pct | A2_REF | 1.068x | 1.114x | 1.001x |
| explore/synthetic_explore/newline/requested_3pct | OFFICIAL_504 | 3.623x | 3.648x | 3.540x |
| explore/synthetic_explore/newline/requested_50pct | A2_REF | 1.007x | 1.035x | 0.999x |
| explore/synthetic_explore/newline/requested_50pct | OFFICIAL_504 | 0.439x | 1.330x | 0.229x |
| explore/synthetic_explore/newline/requested_6pct | A2_REF | 1.045x | 1.092x | 0.999x |
| explore/synthetic_explore/newline/requested_6pct | OFFICIAL_504 | 2.533x | 2.929x | 2.115x |
| explore/synthetic_explore/quote/requested_0pct | A2_REF | 1.124x | 1.162x | 1.001x |
| explore/synthetic_explore/quote/requested_0pct | OFFICIAL_504 | 6.298x | 5.007x | 9.367x |
| explore/synthetic_explore/quote/requested_10pct | A2_REF | 1.029x | 1.069x | 1.001x |
| explore/synthetic_explore/quote/requested_10pct | OFFICIAL_504 | 1.779x | 2.234x | 1.396x |
| explore/synthetic_explore/quote/requested_15pct | A2_REF | 1.022x | 1.051x | 0.999x |
| explore/synthetic_explore/quote/requested_15pct | OFFICIAL_504 | 1.314x | 1.773x | 0.973x |
| explore/synthetic_explore/quote/requested_1pct | A2_REF | 1.095x | 1.142x | 1.004x |
| explore/synthetic_explore/quote/requested_1pct | OFFICIAL_504 | 4.961x | 4.386x | 5.888x |
| explore/synthetic_explore/quote/requested_25pct | A2_REF | 1.015x | 1.044x | 1.000x |
| explore/synthetic_explore/quote/requested_25pct | OFFICIAL_504 | 1.004x | 1.701x | 0.654x |
| explore/synthetic_explore/quote/requested_3pct | A2_REF | 1.067x | 1.117x | 1.001x |
| explore/synthetic_explore/quote/requested_3pct | OFFICIAL_504 | 3.638x | 3.648x | 3.589x |
| explore/synthetic_explore/quote/requested_50pct | A2_REF | 1.007x | 1.036x | 1.000x |
| explore/synthetic_explore/quote/requested_50pct | OFFICIAL_504 | 0.446x | 1.330x | 0.233x |
| explore/synthetic_explore/quote/requested_6pct | A2_REF | 1.043x | 1.088x | 0.998x |
| explore/synthetic_explore/quote/requested_6pct | OFFICIAL_504 | 2.551x | 2.925x | 2.160x |
| explore/synthetic_explore/slash/requested_0pct | A2_REF | 1.121x | 1.161x | 1.002x |
| explore/synthetic_explore/slash/requested_0pct | OFFICIAL_504 | 6.308x | 5.019x | 9.404x |
| explore/synthetic_explore/slash/requested_10pct | A2_REF | 1.027x | 1.049x | 1.001x |
| explore/synthetic_explore/slash/requested_10pct | OFFICIAL_504 | 1.527x | 1.667x | 1.370x |
| explore/synthetic_explore/slash/requested_15pct | A2_REF | 1.019x | 1.046x | 0.999x |
| explore/synthetic_explore/slash/requested_15pct | OFFICIAL_504 | 1.243x | 1.597x | 0.957x |
| explore/synthetic_explore/slash/requested_1pct | A2_REF | 1.098x | 1.138x | 0.998x |
| explore/synthetic_explore/slash/requested_1pct | OFFICIAL_504 | 4.734x | 4.024x | 6.027x |
| explore/synthetic_explore/slash/requested_25pct | A2_REF | 1.015x | 1.045x | 1.000x |
| explore/synthetic_explore/slash/requested_25pct | OFFICIAL_504 | 0.985x | 1.684x | 0.641x |
| explore/synthetic_explore/slash/requested_3pct | A2_REF | 1.059x | 1.097x | 1.003x |
| explore/synthetic_explore/slash/requested_3pct | OFFICIAL_504 | 3.093x | 2.797x | 3.590x |
| explore/synthetic_explore/slash/requested_50pct | A2_REF | 1.007x | 1.035x | 1.000x |
| explore/synthetic_explore/slash/requested_50pct | OFFICIAL_504 | 0.431x | 1.329x | 0.219x |
| explore/synthetic_explore/slash/requested_6pct | A2_REF | 1.038x | 1.066x | 1.001x |
| explore/synthetic_explore/slash/requested_6pct | OFFICIAL_504 | 2.152x | 2.140x | 2.150x |
| explore/synthetic_explore/unicode/requested_0pct | A2_REF | 1.117x | 1.156x | 1.000x |
| explore/synthetic_explore/unicode/requested_0pct | OFFICIAL_504 | 6.296x | 4.985x | 9.397x |
| explore/synthetic_explore/unicode/requested_10pct | A2_REF | 1.028x | 1.074x | 1.001x |
| explore/synthetic_explore/unicode/requested_10pct | OFFICIAL_504 | 1.471x | 2.198x | 1.031x |
| explore/synthetic_explore/unicode/requested_15pct | A2_REF | 1.019x | 1.047x | 1.000x |
| explore/synthetic_explore/unicode/requested_15pct | OFFICIAL_504 | 1.108x | 1.422x | 0.855x |
| explore/synthetic_explore/unicode/requested_1pct | A2_REF | 1.086x | 1.138x | 1.000x |
| explore/synthetic_explore/unicode/requested_1pct | OFFICIAL_504 | 4.747x | 4.405x | 5.207x |
| explore/synthetic_explore/unicode/requested_25pct | A2_REF | 1.022x | 1.040x | 1.002x |
| explore/synthetic_explore/unicode/requested_25pct | OFFICIAL_504 | 1.194x | 1.289x | 1.067x |
| explore/synthetic_explore/unicode/requested_3pct | A2_REF | 1.058x | 1.115x | 0.999x |
| explore/synthetic_explore/unicode/requested_3pct | OFFICIAL_504 | 3.162x | 3.593x | 2.681x |
| explore/synthetic_explore/unicode/requested_50pct | A2_REF | 1.022x | 1.040x | 0.999x |
| explore/synthetic_explore/unicode/requested_50pct | OFFICIAL_504 | 1.194x | 1.290x | 1.068x |
| explore/synthetic_explore/unicode/requested_6pct | A2_REF | 1.041x | 1.094x | 1.003x |
| explore/synthetic_explore/unicode/requested_6pct | OFFICIAL_504 | 2.121x | 2.861x | 1.574x |

## Crossover: backslash count and position

| Phase / count / position | Comparator | DOM | Stage 1 | Stage 2 |
|---|---|---:|---:|---:|
| confirm/synthetic_confirm/crossover/count_0/after512 | A2_REF | 1.170x | 1.229x | 1.001x |
| confirm/synthetic_confirm/crossover/count_0/after512 | OFFICIAL_504 | 6.318x | 5.049x | 9.130x |
| confirm/synthetic_confirm/crossover/count_0/early | A2_REF | 1.170x | 1.229x | 1.000x |
| confirm/synthetic_confirm/crossover/count_0/early | OFFICIAL_504 | 6.320x | 5.056x | 9.138x |
| confirm/synthetic_confirm/crossover/count_1/after512 | A2_REF | 1.169x | 1.227x | 0.998x |
| confirm/synthetic_confirm/crossover/count_1/after512 | OFFICIAL_504 | 6.294x | 5.040x | 9.003x |
| confirm/synthetic_confirm/crossover/count_1/early | A2_REF | 1.170x | 1.227x | 1.000x |
| confirm/synthetic_confirm/crossover/count_1/early | OFFICIAL_504 | 6.294x | 5.043x | 8.970x |
| confirm/synthetic_confirm/crossover/count_12/after512 | A2_REF | 1.160x | 1.221x | 0.997x |
| confirm/synthetic_confirm/crossover/count_12/after512 | OFFICIAL_504 | 6.029x | 4.955x | 8.177x |
| confirm/synthetic_confirm/crossover/count_12/early | A2_REF | 1.157x | 1.219x | 0.998x |
| confirm/synthetic_confirm/crossover/count_12/early | OFFICIAL_504 | 6.043x | 4.964x | 8.247x |
| confirm/synthetic_confirm/crossover/count_16/after512 | A2_REF | 1.156x | 1.221x | 0.999x |
| confirm/synthetic_confirm/crossover/count_16/after512 | OFFICIAL_504 | 5.972x | 4.963x | 7.976x |
| confirm/synthetic_confirm/crossover/count_16/early | A2_REF | 1.155x | 1.219x | 0.998x |
| confirm/synthetic_confirm/crossover/count_16/early | OFFICIAL_504 | 5.970x | 4.968x | 7.963x |
| confirm/synthetic_confirm/crossover/count_2/after512 | A2_REF | 1.168x | 1.227x | 0.999x |
| confirm/synthetic_confirm/crossover/count_2/after512 | OFFICIAL_504 | 6.259x | 5.025x | 8.927x |
| confirm/synthetic_confirm/crossover/count_2/early | A2_REF | 1.168x | 1.227x | 0.998x |
| confirm/synthetic_confirm/crossover/count_2/early | OFFICIAL_504 | 6.264x | 5.033x | 8.859x |
| confirm/synthetic_confirm/crossover/count_32/after512 | A2_REF | 1.152x | 1.226x | 1.001x |
| confirm/synthetic_confirm/crossover/count_32/after512 | OFFICIAL_504 | 5.656x | 4.900x | 6.973x |
| confirm/synthetic_confirm/crossover/count_32/early | A2_REF | 1.140x | 1.210x | 1.000x |
| confirm/synthetic_confirm/crossover/count_32/early | OFFICIAL_504 | 5.468x | 4.805x | 6.468x |
| confirm/synthetic_confirm/crossover/count_4/after512 | A2_REF | 1.166x | 1.225x | 0.999x |
| confirm/synthetic_confirm/crossover/count_4/after512 | OFFICIAL_504 | 6.178x | 5.001x | 8.613x |
| confirm/synthetic_confirm/crossover/count_4/early | A2_REF | 1.166x | 1.225x | 0.998x |
| confirm/synthetic_confirm/crossover/count_4/early | OFFICIAL_504 | 6.204x | 5.007x | 8.668x |
| confirm/synthetic_confirm/crossover/count_8/after512 | A2_REF | 1.161x | 1.225x | 0.990x |
| confirm/synthetic_confirm/crossover/count_8/after512 | OFFICIAL_504 | 6.114x | 4.974x | 8.428x |
| confirm/synthetic_confirm/crossover/count_8/early | A2_REF | 1.166x | 1.227x | 0.998x |
| confirm/synthetic_confirm/crossover/count_8/early | OFFICIAL_504 | 6.153x | 5.000x | 8.588x |
| confirm/synthetic_confirm/crossover/count_9/after512 | A2_REF | 1.161x | 1.221x | 1.000x |
| confirm/synthetic_confirm/crossover/count_9/after512 | OFFICIAL_504 | 6.088x | 4.950x | 8.434x |
| confirm/synthetic_confirm/crossover/count_9/early | A2_REF | 1.161x | 1.220x | 0.998x |
| confirm/synthetic_confirm/crossover/count_9/early | OFFICIAL_504 | 6.101x | 4.962x | 8.499x |
| explore/synthetic_explore/crossover/count_0/after512 | A2_REF | 1.170x | 1.228x | 0.998x |
| explore/synthetic_explore/crossover/count_0/after512 | OFFICIAL_504 | 6.328x | 5.052x | 9.117x |
| explore/synthetic_explore/crossover/count_0/early | A2_REF | 1.170x | 1.228x | 1.001x |
| explore/synthetic_explore/crossover/count_0/early | OFFICIAL_504 | 6.323x | 5.054x | 9.141x |
| explore/synthetic_explore/crossover/count_1/after512 | A2_REF | 1.170x | 1.227x | 1.000x |
| explore/synthetic_explore/crossover/count_1/after512 | OFFICIAL_504 | 6.289x | 5.041x | 9.003x |
| explore/synthetic_explore/crossover/count_1/early | A2_REF | 1.169x | 1.227x | 0.999x |
| explore/synthetic_explore/crossover/count_1/early | OFFICIAL_504 | 6.295x | 5.040x | 8.969x |
| explore/synthetic_explore/crossover/count_12/after512 | A2_REF | 1.158x | 1.221x | 1.000x |
| explore/synthetic_explore/crossover/count_12/after512 | OFFICIAL_504 | 6.032x | 4.953x | 8.182x |
| explore/synthetic_explore/crossover/count_12/early | A2_REF | 1.158x | 1.220x | 0.999x |
| explore/synthetic_explore/crossover/count_12/early | OFFICIAL_504 | 6.045x | 4.969x | 8.244x |
| explore/synthetic_explore/crossover/count_16/after512 | A2_REF | 1.157x | 1.221x | 1.001x |
| explore/synthetic_explore/crossover/count_16/after512 | OFFICIAL_504 | 5.976x | 4.959x | 7.974x |
| explore/synthetic_explore/crossover/count_16/early | A2_REF | 1.156x | 1.219x | 0.999x |
| explore/synthetic_explore/crossover/count_16/early | OFFICIAL_504 | 5.975x | 4.966x | 7.960x |
| explore/synthetic_explore/crossover/count_2/after512 | A2_REF | 1.168x | 1.227x | 0.999x |
| explore/synthetic_explore/crossover/count_2/after512 | OFFICIAL_504 | 6.259x | 5.025x | 8.916x |
| explore/synthetic_explore/crossover/count_2/early | A2_REF | 1.168x | 1.227x | 0.999x |
| explore/synthetic_explore/crossover/count_2/early | OFFICIAL_504 | 6.261x | 5.030x | 8.863x |
| explore/synthetic_explore/crossover/count_32/after512 | A2_REF | 1.151x | 1.225x | 0.999x |
| explore/synthetic_explore/crossover/count_32/after512 | OFFICIAL_504 | 5.650x | 4.900x | 6.967x |
| explore/synthetic_explore/crossover/count_32/early | A2_REF | 1.141x | 1.211x | 1.000x |
| explore/synthetic_explore/crossover/count_32/early | OFFICIAL_504 | 5.468x | 4.808x | 6.473x |
| explore/synthetic_explore/crossover/count_4/after512 | A2_REF | 1.166x | 1.226x | 1.000x |
| explore/synthetic_explore/crossover/count_4/after512 | OFFICIAL_504 | 6.181x | 5.000x | 8.609x |
| explore/synthetic_explore/crossover/count_4/early | A2_REF | 1.166x | 1.226x | 0.999x |
| explore/synthetic_explore/crossover/count_4/early | OFFICIAL_504 | 6.204x | 5.011x | 8.661x |
| explore/synthetic_explore/crossover/count_8/after512 | A2_REF | 1.160x | 1.226x | 0.991x |
| explore/synthetic_explore/crossover/count_8/after512 | OFFICIAL_504 | 6.113x | 4.977x | 8.434x |
| explore/synthetic_explore/crossover/count_8/early | A2_REF | 1.165x | 1.228x | 0.997x |
| explore/synthetic_explore/crossover/count_8/early | OFFICIAL_504 | 6.151x | 5.004x | 8.587x |
| explore/synthetic_explore/crossover/count_9/after512 | A2_REF | 1.162x | 1.222x | 1.000x |
| explore/synthetic_explore/crossover/count_9/after512 | OFFICIAL_504 | 6.091x | 4.956x | 8.435x |
| explore/synthetic_explore/crossover/count_9/early | A2_REF | 1.161x | 1.220x | 0.998x |
| explore/synthetic_explore/crossover/count_9/early | OFFICIAL_504 | 6.103x | 4.966x | 8.505x |

## Decision gate

Look at stage-specific ratios around 8/9 backslashes, across escaped vs public files and explore vs confirm before choosing a Stage 1 or Stage 2 code change.
No automatic promotion. Raw rows: `results102.csv`; input SHA256 and compiler flags are included.
