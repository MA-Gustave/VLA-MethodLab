# Test 106 — VectorPath Release Candidate A/B Validation

State: **completed**; rows: **92435**; phase: **finish**.

## Official JSONTestSuite conformance

See `conformance106.json` and `conformance106.csv` (all y_/n_/i_/transform cases; i_ unscored).
Conformance failures are **not** silently accepted: `production_promotion_eligible` remains false when any expected-label or cross-variant discrepancy is detected.
Failed expected labels and cross-variant differences are reported, NEVER concealed by excluding from performance.
Official y_ performance results are reported separately from original public simdjson-data and synthetic probes.
- Small y_ fixtures have substantial timing overhead; use primarily for correctness, not headline speedup.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_ORIGINAL`: original pinned MethodLab RVV A2 16 KiB packed-off reference.
- `VP_STABLE`: VectorPath shipping candidate A2 defaults 16 KiB, Stage 2 original.
- `VP_SIMPLE`: experimental VectorPath SIMPLE_RUN; `VP_NL4`: NL4 burst on top.
- The RC source is reconstructed from a SHA-256-verified overlay in a separate run directory; MethodLab engine is unchanged.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/jsonsuite_valid/official_y | A2_ORIGINAL | OFFICIAL_504 | 0.6662x | 0.6579x | 0.9104x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | A2_ORIGINAL | 0.9978x | 0.9973x | 1.0006x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | OFFICIAL_504 | 0.6647x | 0.6562x | 0.9109x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | VP_STABLE | 0.9972x | 0.9973x | 1.0005x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | A2_ORIGINAL | 1.0083x | 0.9852x | 0.9965x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | OFFICIAL_504 | 0.6717x | 0.6482x | 0.9072x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | VP_STABLE | 1.0078x | 0.9852x | 0.9964x |
| confirm/jsonsuite_valid/official_y | VP_STABLE | A2_ORIGINAL | 1.0005x | 1.0000x | 1.0001x |
| confirm/jsonsuite_valid/official_y | VP_STABLE | OFFICIAL_504 | 0.6665x | 0.6580x | 0.9105x |
| confirm/public_original/public | A2_ORIGINAL | OFFICIAL_504 | 1.6007x | 2.0375x | 1.2734x |
| confirm/public_original/public | VP_NL4 | A2_ORIGINAL | 0.9937x | 0.9973x | 0.9872x |
| confirm/public_original/public | VP_NL4 | OFFICIAL_504 | 1.5907x | 2.0320x | 1.2571x |
| confirm/public_original/public | VP_NL4 | VP_STABLE | 0.9937x | 0.9973x | 0.9878x |
| confirm/public_original/public | VP_SIMPLE | A2_ORIGINAL | 0.9965x | 0.9996x | 0.9914x |
| confirm/public_original/public | VP_SIMPLE | OFFICIAL_504 | 1.5950x | 2.0367x | 1.2624x |
| confirm/public_original/public | VP_SIMPLE | VP_STABLE | 0.9965x | 0.9995x | 0.9920x |
| confirm/public_original/public | VP_STABLE | A2_ORIGINAL | 1.0000x | 1.0000x | 0.9994x |
| confirm/public_original/public | VP_STABLE | OFFICIAL_504 | 1.6007x | 2.0376x | 1.2727x |
| confirm/synthetic_confirm/mixed | A2_ORIGINAL | OFFICIAL_504 | 1.4772x | 2.2306x | 1.1573x |
| confirm/synthetic_confirm/mixed | VP_NL4 | A2_ORIGINAL | 1.3318x | 0.9940x | 1.5784x |
| confirm/synthetic_confirm/mixed | VP_NL4 | OFFICIAL_504 | 1.9673x | 2.2171x | 1.8267x |
| confirm/synthetic_confirm/mixed | VP_NL4 | VP_STABLE | 1.3306x | 0.9923x | 1.5766x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | A2_ORIGINAL | 1.3434x | 0.9961x | 1.5838x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | OFFICIAL_504 | 1.9844x | 2.2218x | 1.8330x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | VP_STABLE | 1.3422x | 0.9944x | 1.5821x |
| confirm/synthetic_confirm/mixed | VP_STABLE | A2_ORIGINAL | 1.0009x | 1.0017x | 1.0011x |
| confirm/synthetic_confirm/mixed | VP_STABLE | OFFICIAL_504 | 1.4785x | 2.2344x | 1.1586x |
| confirm/synthetic_confirm/newline | A2_ORIGINAL | OFFICIAL_504 | 1.4786x | 2.2206x | 1.1691x |
| confirm/synthetic_confirm/newline | VP_NL4 | A2_ORIGINAL | 1.3704x | 0.9935x | 1.7114x |
| confirm/synthetic_confirm/newline | VP_NL4 | OFFICIAL_504 | 2.0263x | 2.2062x | 2.0007x |
| confirm/synthetic_confirm/newline | VP_NL4 | VP_STABLE | 1.3709x | 0.9930x | 1.7139x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | A2_ORIGINAL | 1.3245x | 0.9965x | 1.5371x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | OFFICIAL_504 | 1.9584x | 2.2128x | 1.7970x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | VP_STABLE | 1.3250x | 0.9960x | 1.5394x |
| confirm/synthetic_confirm/newline | VP_STABLE | A2_ORIGINAL | 0.9997x | 1.0005x | 0.9985x |
| confirm/synthetic_confirm/newline | VP_STABLE | OFFICIAL_504 | 1.4781x | 2.2217x | 1.1674x |
| confirm/synthetic_confirm/unicode | A2_ORIGINAL | OFFICIAL_504 | 1.9078x | 2.0466x | 1.8231x |
| confirm/synthetic_confirm/unicode | VP_NL4 | A2_ORIGINAL | 0.9706x | 0.9958x | 0.9450x |
| confirm/synthetic_confirm/unicode | VP_NL4 | OFFICIAL_504 | 1.8518x | 2.0381x | 1.7228x |
| confirm/synthetic_confirm/unicode | VP_NL4 | VP_STABLE | 0.9708x | 0.9949x | 0.9437x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | A2_ORIGINAL | 0.9978x | 0.9973x | 0.9988x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | OFFICIAL_504 | 1.9036x | 2.0411x | 1.8210x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | VP_STABLE | 0.9980x | 0.9963x | 0.9975x |
| confirm/synthetic_confirm/unicode | VP_STABLE | A2_ORIGINAL | 0.9998x | 1.0010x | 1.0013x |
| confirm/synthetic_confirm/unicode | VP_STABLE | OFFICIAL_504 | 1.9075x | 2.0486x | 1.8255x |
| explore/jsonsuite_valid/official_y | A2_ORIGINAL | OFFICIAL_504 | 0.6664x | 0.6574x | 0.9102x |
| explore/jsonsuite_valid/official_y | VP_NL4 | A2_ORIGINAL | 0.9975x | 0.9976x | 1.0007x |
| explore/jsonsuite_valid/official_y | VP_NL4 | OFFICIAL_504 | 0.6648x | 0.6559x | 0.9109x |
| explore/jsonsuite_valid/official_y | VP_NL4 | VP_STABLE | 0.9977x | 0.9972x | 1.0005x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | A2_ORIGINAL | 1.0084x | 0.9859x | 0.9969x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | OFFICIAL_504 | 0.6720x | 0.6481x | 0.9073x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | VP_STABLE | 1.0085x | 0.9854x | 0.9966x |
| explore/jsonsuite_valid/official_y | VP_STABLE | A2_ORIGINAL | 0.9999x | 1.0004x | 1.0003x |
| explore/jsonsuite_valid/official_y | VP_STABLE | OFFICIAL_504 | 0.6663x | 0.6577x | 0.9104x |
| explore/public_original/public | A2_ORIGINAL | OFFICIAL_504 | 1.6081x | 2.0355x | 1.2842x |
| explore/public_original/public | VP_NL4 | A2_ORIGINAL | 0.9935x | 0.9981x | 0.9861x |
| explore/public_original/public | VP_NL4 | OFFICIAL_504 | 1.5976x | 2.0316x | 1.2663x |
| explore/public_original/public | VP_NL4 | VP_STABLE | 0.9939x | 0.9983x | 0.9871x |
| explore/public_original/public | VP_SIMPLE | A2_ORIGINAL | 0.9964x | 0.9995x | 0.9898x |
| explore/public_original/public | VP_SIMPLE | OFFICIAL_504 | 1.6023x | 2.0345x | 1.2711x |
| explore/public_original/public | VP_SIMPLE | VP_STABLE | 0.9968x | 0.9998x | 0.9909x |
| explore/public_original/public | VP_STABLE | A2_ORIGINAL | 0.9996x | 0.9998x | 0.9989x |
| explore/public_original/public | VP_STABLE | OFFICIAL_504 | 1.6075x | 2.0350x | 1.2828x |
| explore/synthetic_explore/mixed | A2_ORIGINAL | OFFICIAL_504 | 1.4737x | 2.2196x | 1.1586x |
| explore/synthetic_explore/mixed | VP_NL4 | A2_ORIGINAL | 1.3300x | 0.9922x | 1.5780x |
| explore/synthetic_explore/mixed | VP_NL4 | OFFICIAL_504 | 1.9600x | 2.2024x | 1.8282x |
| explore/synthetic_explore/mixed | VP_NL4 | VP_STABLE | 1.3291x | 0.9925x | 1.5781x |
| explore/synthetic_explore/mixed | VP_SIMPLE | A2_ORIGINAL | 1.3409x | 0.9937x | 1.5817x |
| explore/synthetic_explore/mixed | VP_SIMPLE | OFFICIAL_504 | 1.9760x | 2.2057x | 1.8324x |
| explore/synthetic_explore/mixed | VP_SIMPLE | VP_STABLE | 1.3400x | 0.9940x | 1.5818x |
| explore/synthetic_explore/mixed | VP_STABLE | A2_ORIGINAL | 1.0007x | 0.9997x | 0.9999x |
| explore/synthetic_explore/mixed | VP_STABLE | OFFICIAL_504 | 1.4747x | 2.2190x | 1.1584x |
| explore/synthetic_explore/newline | A2_ORIGINAL | OFFICIAL_504 | 1.4794x | 2.2220x | 1.1686x |
| explore/synthetic_explore/newline | VP_NL4 | A2_ORIGINAL | 1.3677x | 0.9928x | 1.7117x |
| explore/synthetic_explore/newline | VP_NL4 | OFFICIAL_504 | 2.0234x | 2.2059x | 2.0003x |
| explore/synthetic_explore/newline | VP_NL4 | VP_STABLE | 1.3661x | 0.9925x | 1.7080x |
| explore/synthetic_explore/newline | VP_SIMPLE | A2_ORIGINAL | 1.3228x | 0.9952x | 1.5352x |
| explore/synthetic_explore/newline | VP_SIMPLE | OFFICIAL_504 | 1.9569x | 2.2112x | 1.7940x |
| explore/synthetic_explore/newline | VP_SIMPLE | VP_STABLE | 1.3212x | 0.9949x | 1.5319x |
| explore/synthetic_explore/newline | VP_STABLE | A2_ORIGINAL | 1.0012x | 1.0003x | 1.0022x |
| explore/synthetic_explore/newline | VP_STABLE | OFFICIAL_504 | 1.4812x | 2.2226x | 1.1711x |
| explore/synthetic_explore/unicode | A2_ORIGINAL | OFFICIAL_504 | 1.9068x | 2.0503x | 1.8209x |
| explore/synthetic_explore/unicode | VP_NL4 | A2_ORIGINAL | 0.9702x | 0.9954x | 0.9453x |
| explore/synthetic_explore/unicode | VP_NL4 | OFFICIAL_504 | 1.8501x | 2.0409x | 1.7213x |
| explore/synthetic_explore/unicode | VP_NL4 | VP_STABLE | 0.9696x | 0.9953x | 0.9444x |
| explore/synthetic_explore/unicode | VP_SIMPLE | A2_ORIGINAL | 0.9984x | 0.9970x | 1.0009x |
| explore/synthetic_explore/unicode | VP_SIMPLE | OFFICIAL_504 | 1.9037x | 2.0441x | 1.8226x |
| explore/synthetic_explore/unicode | VP_SIMPLE | VP_STABLE | 0.9977x | 0.9969x | 0.9999x |
| explore/synthetic_explore/unicode | VP_STABLE | A2_ORIGINAL | 1.0006x | 1.0001x | 1.0010x |
| explore/synthetic_explore/unicode | VP_STABLE | OFFICIAL_504 | 1.9081x | 2.0505x | 1.8227x |

## Same-machine public release gate (confirmation only)

| Candidate | Geomean / original A2 | Worst public file | Local machine gate |
|---|---:|---:|---|
| VP_STABLE | 1.00001x | 0.9976x | local_machine_pass |
| VP_SIMPLE | 0.99646x | 0.9851x | local_machine_pass |
| VP_NL4 | 0.99372x | 0.9797x | local_machine_regression |

## Release promotion decision — NOT automatic

Use JSONTestSuite conformance, actual per-machine gains and exact binary SHA256 from builds106.json.

Investigate any original public JSON below 0.98x versus original A2; require public geometric mean >=0.995 on both machines.
Do not globally enable opt-in Stage 2 paths without independent real escaped workload evidence.

## Density sweep and crossover

The exact density and crossover breakdown is in `summary106.json`; per-document public ratios and same-machine gate are in `public_gate106.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
