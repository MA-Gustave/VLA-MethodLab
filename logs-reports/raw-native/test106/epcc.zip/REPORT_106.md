# Test 106 — VectorPath Release Candidate A/B Validation

State: **completed**; rows: **75400**; phase: **finish**.

## Official JSONTestSuite conformance

See `conformance106.json` and `conformance106.csv` (all y_/n_/i_/transform cases; i_ unscored).
Conformance failures are **not** silently accepted: `production_promotion_eligible` remains false when any expected-label or cross-variant discrepancy is detected.
Failed expected labels and cross-variant differences are reported, NEVER concealed by excluding from performance.
Official y_ performance results are reported separately from original public simdjson-data and synthetic probes.
- Small y_ fixtures have substantial timing overhead; use primarily for correctness, not headline speedup.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_ORIGINAL`: original pinned MethodLab RVV A2 16 KiB packed-off reference.
- `VP_STABLE`: VectorPath shipping candidate A2 defaults 16 KiB, Stage 2 original.
- `VP_SIMPLE`: experimental VectorPath SIMPLE_RUN; `VP_NL4`: NL4 burst on top.
- The RC source is reconstructed from a SHA-256-verified overlay in a separate run directory; MethodLab engine is unchanged.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/jsonsuite_valid/official_y | A2_ORIGINAL | OFFICIAL_504 | 0.8497x | 0.8498x | 0.9157x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | A2_ORIGINAL | 0.9976x | 0.9997x | 1.0142x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | OFFICIAL_504 | 0.8476x | 0.8496x | 0.9287x |
| confirm/jsonsuite_valid/official_y | VP_NL4 | VP_STABLE | 0.9976x | 1.0000x | 1.0148x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | A2_ORIGINAL | 0.9972x | 0.9993x | 1.0130x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | OFFICIAL_504 | 0.8473x | 0.8492x | 0.9276x |
| confirm/jsonsuite_valid/official_y | VP_SIMPLE | VP_STABLE | 0.9972x | 0.9996x | 1.0136x |
| confirm/jsonsuite_valid/official_y | VP_STABLE | A2_ORIGINAL | 1.0000x | 0.9997x | 0.9994x |
| confirm/jsonsuite_valid/official_y | VP_STABLE | OFFICIAL_504 | 0.8497x | 0.8496x | 0.9152x |
| confirm/public_original/public | A2_ORIGINAL | OFFICIAL_504 | 1.8954x | 2.5036x | 1.4691x |
| confirm/public_original/public | VP_NL4 | A2_ORIGINAL | 1.0038x | 1.0000x | 1.0070x |
| confirm/public_original/public | VP_NL4 | OFFICIAL_504 | 1.9026x | 2.5036x | 1.4794x |
| confirm/public_original/public | VP_NL4 | VP_STABLE | 1.0042x | 1.0000x | 1.0073x |
| confirm/public_original/public | VP_SIMPLE | A2_ORIGINAL | 1.0031x | 1.0011x | 1.0063x |
| confirm/public_original/public | VP_SIMPLE | OFFICIAL_504 | 1.9012x | 2.5063x | 1.4784x |
| confirm/public_original/public | VP_SIMPLE | VP_STABLE | 1.0035x | 1.0011x | 1.0066x |
| confirm/public_original/public | VP_STABLE | A2_ORIGINAL | 0.9996x | 1.0000x | 0.9997x |
| confirm/public_original/public | VP_STABLE | OFFICIAL_504 | 1.8946x | 2.5035x | 1.4687x |
| confirm/synthetic_confirm/mixed | A2_ORIGINAL | OFFICIAL_504 | 1.7629x | 2.8671x | 1.3180x |
| confirm/synthetic_confirm/mixed | VP_NL4 | A2_ORIGINAL | 1.3820x | 0.9957x | 1.6299x |
| confirm/synthetic_confirm/mixed | VP_NL4 | OFFICIAL_504 | 2.4363x | 2.8549x | 2.1481x |
| confirm/synthetic_confirm/mixed | VP_NL4 | VP_STABLE | 1.3816x | 0.9966x | 1.6285x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | A2_ORIGINAL | 1.3919x | 1.0029x | 1.6466x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | OFFICIAL_504 | 2.4537x | 2.8754x | 2.1701x |
| confirm/synthetic_confirm/mixed | VP_SIMPLE | VP_STABLE | 1.3915x | 1.0037x | 1.6452x |
| confirm/synthetic_confirm/mixed | VP_STABLE | A2_ORIGINAL | 1.0003x | 0.9992x | 1.0008x |
| confirm/synthetic_confirm/mixed | VP_STABLE | OFFICIAL_504 | 1.7634x | 2.8647x | 1.3191x |
| confirm/synthetic_confirm/newline | A2_ORIGINAL | OFFICIAL_504 | 1.7714x | 2.8645x | 1.3454x |
| confirm/synthetic_confirm/newline | VP_NL4 | A2_ORIGINAL | 1.4634x | 0.9973x | 1.8880x |
| confirm/synthetic_confirm/newline | VP_NL4 | OFFICIAL_504 | 2.5924x | 2.8568x | 2.5403x |
| confirm/synthetic_confirm/newline | VP_NL4 | VP_STABLE | 1.4640x | 0.9973x | 1.8908x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | A2_ORIGINAL | 1.3813x | 1.0033x | 1.6124x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | OFFICIAL_504 | 2.4468x | 2.8739x | 2.1694x |
| confirm/synthetic_confirm/newline | VP_SIMPLE | VP_STABLE | 1.3818x | 1.0033x | 1.6148x |
| confirm/synthetic_confirm/newline | VP_STABLE | A2_ORIGINAL | 0.9996x | 1.0000x | 0.9985x |
| confirm/synthetic_confirm/newline | VP_STABLE | OFFICIAL_504 | 1.7707x | 2.8644x | 1.3435x |
| confirm/synthetic_confirm/unicode | A2_ORIGINAL | OFFICIAL_504 | 2.3185x | 2.7625x | 1.8323x |
| confirm/synthetic_confirm/unicode | VP_NL4 | A2_ORIGINAL | 0.9982x | 0.9981x | 0.9954x |
| confirm/synthetic_confirm/unicode | VP_NL4 | OFFICIAL_504 | 2.3144x | 2.7571x | 1.8239x |
| confirm/synthetic_confirm/unicode | VP_NL4 | VP_STABLE | 0.9978x | 0.9985x | 0.9956x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | A2_ORIGINAL | 1.0007x | 1.0042x | 0.9963x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | OFFICIAL_504 | 2.3201x | 2.7740x | 1.8255x |
| confirm/synthetic_confirm/unicode | VP_SIMPLE | VP_STABLE | 1.0003x | 1.0046x | 0.9965x |
| confirm/synthetic_confirm/unicode | VP_STABLE | A2_ORIGINAL | 1.0004x | 0.9996x | 0.9998x |
| confirm/synthetic_confirm/unicode | VP_STABLE | OFFICIAL_504 | 2.3194x | 2.7614x | 1.8319x |
| explore/jsonsuite_valid/official_y | A2_ORIGINAL | OFFICIAL_504 | 0.8496x | 0.8496x | 0.9163x |
| explore/jsonsuite_valid/official_y | VP_NL4 | A2_ORIGINAL | 0.9974x | 0.9998x | 1.0132x |
| explore/jsonsuite_valid/official_y | VP_NL4 | OFFICIAL_504 | 0.8475x | 0.8494x | 0.9284x |
| explore/jsonsuite_valid/official_y | VP_NL4 | VP_STABLE | 0.9970x | 0.9995x | 1.0129x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | A2_ORIGINAL | 0.9970x | 0.9992x | 1.0126x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | OFFICIAL_504 | 0.8471x | 0.8490x | 0.9278x |
| explore/jsonsuite_valid/official_y | VP_SIMPLE | VP_STABLE | 0.9965x | 0.9990x | 1.0122x |
| explore/jsonsuite_valid/official_y | VP_STABLE | A2_ORIGINAL | 1.0005x | 1.0003x | 1.0004x |
| explore/jsonsuite_valid/official_y | VP_STABLE | OFFICIAL_504 | 0.8500x | 0.8499x | 0.9166x |
| explore/public_original/public | A2_ORIGINAL | OFFICIAL_504 | 1.8947x | 2.5029x | 1.4691x |
| explore/public_original/public | VP_NL4 | A2_ORIGINAL | 1.0033x | 1.0000x | 1.0080x |
| explore/public_original/public | VP_NL4 | OFFICIAL_504 | 1.9010x | 2.5030x | 1.4808x |
| explore/public_original/public | VP_NL4 | VP_STABLE | 1.0037x | 1.0003x | 1.0088x |
| explore/public_original/public | VP_SIMPLE | A2_ORIGINAL | 1.0029x | 1.0004x | 1.0049x |
| explore/public_original/public | VP_SIMPLE | OFFICIAL_504 | 1.9002x | 2.5039x | 1.4763x |
| explore/public_original/public | VP_SIMPLE | VP_STABLE | 1.0033x | 1.0007x | 1.0057x |
| explore/public_original/public | VP_STABLE | A2_ORIGINAL | 0.9996x | 0.9997x | 0.9992x |
| explore/public_original/public | VP_STABLE | OFFICIAL_504 | 1.8940x | 2.5021x | 1.4679x |
| explore/synthetic_explore/mixed | A2_ORIGINAL | OFFICIAL_504 | 1.7629x | 2.8602x | 1.3203x |
| explore/synthetic_explore/mixed | VP_NL4 | A2_ORIGINAL | 1.3822x | 0.9977x | 1.6306x |
| explore/synthetic_explore/mixed | VP_NL4 | OFFICIAL_504 | 2.4366x | 2.8537x | 2.1530x |
| explore/synthetic_explore/mixed | VP_NL4 | VP_STABLE | 1.3817x | 0.9977x | 1.6308x |
| explore/synthetic_explore/mixed | VP_SIMPLE | A2_ORIGINAL | 1.3908x | 1.0035x | 1.6417x |
| explore/synthetic_explore/mixed | VP_SIMPLE | OFFICIAL_504 | 2.4517x | 2.8702x | 2.1677x |
| explore/synthetic_explore/mixed | VP_SIMPLE | VP_STABLE | 1.3903x | 1.0035x | 1.6419x |
| explore/synthetic_explore/mixed | VP_STABLE | A2_ORIGINAL | 1.0003x | 1.0000x | 0.9999x |
| explore/synthetic_explore/mixed | VP_STABLE | OFFICIAL_504 | 1.7634x | 2.8602x | 1.3202x |
| explore/synthetic_explore/newline | A2_ORIGINAL | OFFICIAL_504 | 1.7634x | 2.8631x | 1.3379x |
| explore/synthetic_explore/newline | VP_NL4 | A2_ORIGINAL | 1.4670x | 0.9981x | 1.8884x |
| explore/synthetic_explore/newline | VP_NL4 | OFFICIAL_504 | 2.5869x | 2.8578x | 2.5263x |
| explore/synthetic_explore/newline | VP_NL4 | VP_STABLE | 1.4627x | 0.9968x | 1.8867x |
| explore/synthetic_explore/newline | VP_SIMPLE | A2_ORIGINAL | 1.3852x | 1.0037x | 1.6119x |
| explore/synthetic_explore/newline | VP_SIMPLE | OFFICIAL_504 | 2.4427x | 2.8737x | 2.1564x |
| explore/synthetic_explore/newline | VP_SIMPLE | VP_STABLE | 1.3812x | 1.0023x | 1.6105x |
| explore/synthetic_explore/newline | VP_STABLE | A2_ORIGINAL | 1.0029x | 1.0014x | 1.0009x |
| explore/synthetic_explore/newline | VP_STABLE | OFFICIAL_504 | 1.7686x | 2.8671x | 1.3390x |
| explore/synthetic_explore/unicode | A2_ORIGINAL | OFFICIAL_504 | 2.3193x | 2.7666x | 1.8341x |
| explore/synthetic_explore/unicode | VP_NL4 | A2_ORIGINAL | 0.9985x | 0.9982x | 0.9950x |
| explore/synthetic_explore/unicode | VP_NL4 | OFFICIAL_504 | 2.3158x | 2.7616x | 1.8249x |
| explore/synthetic_explore/unicode | VP_NL4 | VP_STABLE | 0.9974x | 0.9981x | 0.9940x |
| explore/synthetic_explore/unicode | VP_SIMPLE | A2_ORIGINAL | 1.0006x | 1.0039x | 0.9952x |
| explore/synthetic_explore/unicode | VP_SIMPLE | OFFICIAL_504 | 2.3206x | 2.7774x | 1.8252x |
| explore/synthetic_explore/unicode | VP_SIMPLE | VP_STABLE | 0.9995x | 1.0038x | 0.9942x |
| explore/synthetic_explore/unicode | VP_STABLE | A2_ORIGINAL | 1.0011x | 1.0001x | 1.0009x |
| explore/synthetic_explore/unicode | VP_STABLE | OFFICIAL_504 | 2.3219x | 2.7669x | 1.8358x |

## Same-machine public release gate (confirmation only)

| Candidate | Geomean / original A2 | Worst public file | Local machine gate |
|---|---:|---:|---|
| VP_STABLE | 0.99959x | 0.9970x | local_machine_pass |
| VP_SIMPLE | 1.00309x | 0.9976x | local_machine_pass |
| VP_NL4 | 1.00382x | 0.9976x | local_machine_pass |

## Release promotion decision — NOT automatic

Use JSONTestSuite conformance, actual per-machine gains and exact binary SHA256 from builds106.json.

Investigate any original public JSON below 0.98x versus original A2; require public geometric mean >=0.995 on both machines.
Do not globally enable opt-in Stage 2 paths without independent real escaped workload evidence.

## Density sweep and crossover

The exact density and crossover breakdown is in `summary106.json`; per-document public ratios and same-machine gate are in `public_gate106.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
