# Test 101 — Adaptive public JSON + targeted dispatch boundaries

State: **completed**; measurement rows: **22050**.
Stop reason: precision_reached.

## Provenance and interpretation

- Public data: **18 byte-identical simdjson-data examples**, pinned 4197c425e857f0ec38e89822fdd0bd9ea21f4daf.
- Derived data: **structural fragments reconstructed from pinned public files**, not independent real-world documents.
- Synthetic data: **87 deterministic exact-size boundary fixtures**, clearly separate.
- Public original, public-derived, and synthetic categories are NEVER pooled into one ranking.
- Official baseline is **simdjson 5.0.4 fallback**; experimental A2 uses **RVV**.
- Previous EPCC Test99 v5.0.3 and 5.0.4 compiled to identical ELF SHA-256; Test101 avoids a redundant v5.0.3 binary.
- Timing repeats are not an independent-document holdout.
- Interval estimates use repeated rounds, not separate JSON documents as independent timing observations.

## Paired geometric mean DOM throughput ratios versus A2_REF

| Workload (separate) | Variant | Geomean ratio | Documents |
|---|---|---:|---:|
| public_original | OFFICIAL_504 | 0.61579× | 18 |
| public_original | A2_G8192 | 1.00003× | 18 |
| public_original | A2_G10240 | 0.99813× | 18 |
| public_original | A2_G12288 | 1.00209× | 18 |
| public_original | A2_G16384 | 1.00313× | 18 |
| public_derived | OFFICIAL_504 | 0.64088× | 42 |
| public_derived | A2_G8192 | 1.03665× | 42 |
| public_derived | A2_G10240 | 1.03603× | 42 |
| public_derived | A2_G12288 | 1.04230× | 42 |
| public_derived | A2_G16384 | 1.04756× | 42 |
| synthetic_boundary | OFFICIAL_504 | 0.63750× | 87 |
| synthetic_boundary | A2_G8192 | 1.04038× | 87 |
| synthetic_boundary | A2_G10240 | 1.04905× | 87 |
| synthetic_boundary | A2_G12288 | 1.06223× | 87 |
| synthetic_boundary | A2_G16384 | 1.07435× | 87 |

## Direct comparison versus 8 KiB (A2_G8192)

| Workload (separate) | Variant | Geomean vs 8 KiB | Documents |
|---|---|---:|---:|
| public_original | OFFICIAL_504 | 0.61577× | 18 |
| public_original | A2_REF | 0.99997× | 18 |
| public_original | A2_G10240 | 0.99810× | 18 |
| public_original | A2_G12288 | 1.00206× | 18 |
| public_original | A2_G16384 | 1.00310× | 18 |
| public_derived | OFFICIAL_504 | 0.61822× | 42 |
| public_derived | A2_REF | 0.96465× | 42 |
| public_derived | A2_G10240 | 0.99940× | 42 |
| public_derived | A2_G12288 | 1.00545× | 42 |
| public_derived | A2_G16384 | 1.01053× | 42 |
| synthetic_boundary | OFFICIAL_504 | 0.61276× | 87 |
| synthetic_boundary | A2_REF | 0.96119× | 87 |
| synthetic_boundary | A2_G10240 | 1.00834× | 87 |
| synthetic_boundary | A2_G12288 | 1.02101× | 87 |
| synthetic_boundary | A2_G16384 | 1.03266× | 87 |

Values above one are faster. The source-equal geomean for derived fragments is in summary101.json.

Ratios above 1 indicate a faster candidate than the named reference.

## Sequential confidence checks by separate stratum

| Candidate | Ratio | Approx. 95% half-width | Complete rounds |
|---|---:|---:|---:|
| public_original/A2_G8192 | 1.00080× | ±0.095% | 25 |
| public_original/A2_G10240 | 0.99890× | ±0.075% | 25 |
| public_original/A2_G12288 | 1.00286× | ±0.098% | 25 |
| public_original/A2_G16384 | 1.00391× | ±0.106% | 25 |
| public_derived/A2_G8192 | 1.03609× | ±0.067% | 25 |
| public_derived/A2_G10240 | 1.03547× | ±0.064% | 25 |
| public_derived/A2_G12288 | 1.04174× | ±0.042% | 25 |
| public_derived/A2_G16384 | 1.04700× | ±0.070% | 25 |
| synthetic_boundary/A2_G8192 | 1.04076× | ±0.048% | 25 |
| synthetic_boundary/A2_G10240 | 1.04943× | ±0.051% | 25 |
| synthetic_boundary/A2_G12288 | 1.06262× | ±0.044% | 25 |
| synthetic_boundary/A2_G16384 | 1.07475× | ±0.053% | 25 |

## Run health

- Reference before/after median absolute drift: 0.25196219559024957 percent.
- Reference comparisons exceeding 10% drift: 0.005442176870748299 fraction.
- A candidate is not promoted automatically; examine per-document results and machine noise.

Raw rows: `results101.csv`; machine/build/provenance: JSON files in this archive.
