# Test 101 — Adaptive public JSON + targeted dispatch boundaries

State: **completed**; measurement rows: **19404**.
Stop reason: precision_reached.

## Provenance and interpretation

- Public data: **18 byte-identical simdjson-data examples**, pinned 4197c425e857f0ec38e89822fdd0bd9ea21f4daf.
- Derived data: **structural fragments reconstructed from pinned public files**, not independent real-world documents.
- Synthetic data: **87 deterministic exact-size boundary fixtures**, clearly separate.
- Public original, public-derived, and synthetic categories are NEVER pooled into one ranking.
- Official baseline is **simdjson 5.0.4 fallback**; experimental A2 uses **RVV**.
- Previous EPCC Test99 v5.0.3 and 5.0.4 compiled to identical ELF SHA-256; Test101 avoids a redundant v5.0.3 binary.
- Timing repeats are not an independent-document holdout.
- Interval estimates use repeated rounds, not separate JSON documents as independent timing observations.

## Paired geometric mean DOM throughput ratios versus A2_REF

| Workload (separate) | Variant | Geomean ratio | Documents |
|---|---|---:|---:|
| public_original | OFFICIAL_504 | 0.53360× | 18 |
| public_original | A2_G8192 | 0.99924× | 18 |
| public_original | A2_G10240 | 1.00386× | 18 |
| public_original | A2_G12288 | 1.00531× | 18 |
| public_original | A2_G16384 | 1.00713× | 18 |
| public_derived | OFFICIAL_504 | 0.53706× | 42 |
| public_derived | A2_G8192 | 1.05055× | 42 |
| public_derived | A2_G10240 | 1.05485× | 42 |
| public_derived | A2_G12288 | 1.06083× | 42 |
| public_derived | A2_G16384 | 1.07000× | 42 |
| synthetic_boundary | OFFICIAL_504 | 0.57617× | 87 |
| synthetic_boundary | A2_G8192 | 1.05133× | 87 |
| synthetic_boundary | A2_G10240 | 1.06640× | 87 |
| synthetic_boundary | A2_G12288 | 1.07896× | 87 |
| synthetic_boundary | A2_G16384 | 1.09317× | 87 |

## Direct comparison versus 8 KiB (A2_G8192)

| Workload (separate) | Variant | Geomean vs 8 KiB | Documents |
|---|---|---:|---:|
| public_original | OFFICIAL_504 | 0.53401× | 18 |
| public_original | A2_REF | 1.00077× | 18 |
| public_original | A2_G10240 | 1.00463× | 18 |
| public_original | A2_G12288 | 1.00608× | 18 |
| public_original | A2_G16384 | 1.00790× | 18 |
| public_derived | OFFICIAL_504 | 0.51122× | 42 |
| public_derived | A2_REF | 0.95188× | 42 |
| public_derived | A2_G10240 | 1.00410× | 42 |
| public_derived | A2_G12288 | 1.00979× | 42 |
| public_derived | A2_G16384 | 1.01851× | 42 |
| synthetic_boundary | OFFICIAL_504 | 0.54803× | 87 |
| synthetic_boundary | A2_REF | 0.95117× | 87 |
| synthetic_boundary | A2_G10240 | 1.01433× | 87 |
| synthetic_boundary | A2_G12288 | 1.02628× | 87 |
| synthetic_boundary | A2_G16384 | 1.03980× | 87 |

Values above one are faster. The source-equal geomean for derived fragments is in summary101.json.

Ratios above 1 indicate a faster candidate than the named reference.

## Sequential confidence checks by separate stratum

| Candidate | Ratio | Approx. 95% half-width | Complete rounds |
|---|---:|---:|---:|
| public_original/A2_G8192 | 0.99969× | ±0.071% | 22 |
| public_original/A2_G10240 | 1.00432× | ±0.084% | 22 |
| public_original/A2_G12288 | 1.00577× | ±0.094% | 22 |
| public_original/A2_G16384 | 1.00759× | ±0.071% | 22 |
| public_derived/A2_G8192 | 1.05065× | ±0.056% | 22 |
| public_derived/A2_G10240 | 1.05496× | ±0.050% | 22 |
| public_derived/A2_G12288 | 1.06094× | ±0.049% | 22 |
| public_derived/A2_G16384 | 1.07010× | ±0.042% | 22 |
| synthetic_boundary/A2_G8192 | 1.05119× | ±0.045% | 22 |
| synthetic_boundary/A2_G10240 | 1.06625× | ±0.045% | 22 |
| synthetic_boundary/A2_G12288 | 1.07881× | ±0.050% | 22 |
| synthetic_boundary/A2_G16384 | 1.09302× | ±0.047% | 22 |

## Run health

- Reference before/after median absolute drift: 0.28079235363322463 percent.
- Reference comparisons exceeding 10% drift: 0.00030921459492888067 fraction.
- A candidate is not promoted automatically; examine per-document results and machine noise.

Raw rows: `results101.csv`; machine/build/provenance: JSON files in this archive.
