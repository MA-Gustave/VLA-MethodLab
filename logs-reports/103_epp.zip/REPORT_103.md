# Test 103 — Real Stage 2 escape-decoder optimization

State: **completed**; rows: **101536**; phase: **finish**.

## Variant definitions

- `OFFICIAL_504`: unmodified simdjson v5.0.4, fallback backend.
- `A2_G16384`: unmodified RVV A2, 16 KiB dispatch threshold.
- `A2_SIMPLE_RUN`: A2 with scalar consecutive simple-escape decoding inside Stage 2.
- `A2_NL4`: A2 with the same scalar run and four-pair `\n` burst specialization.
- These are **experimental compile-only overlays**. No production checkout is mutated.

## Measurement interpretation

- Separate DOM, internal Stage 1, internal Stage 2: not additive.
- Public inputs and generated synthetic stress are NEVER pooled.
- Explore and confirm synthetic seeds are distinct; repeat runs are not independent source samples.
- Synthetic 50% backslash stress is intentionally pathological.
- Per-machine results only; no pooled EPCC/Cloud-V speedup.

## Paired geometric throughput ratios (above 1.0 is faster)

| Phase / workload | Candidate | Baseline | DOM | Stage 1 | Stage 2 |
|---|---|---|---:|---:|---:|
| confirm/public_original/public | A2_G16384 | OFFICIAL_504 | 1.8927x | 2.5029x | 1.4680x |
| confirm/public_original/public | A2_NL4 | A2_G16384 | 1.0033x | 0.9997x | 1.0069x |
| confirm/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 1.0000x | 0.9990x | 1.0013x |
| confirm/public_original/public | A2_NL4 | OFFICIAL_504 | 1.8990x | 2.5021x | 1.4782x |
| confirm/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 1.0033x | 1.0007x | 1.0056x |
| confirm/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.8989x | 2.5047x | 1.4762x |
| confirm/synthetic_confirm/crossover | A2_G16384 | OFFICIAL_504 | 7.8311x | 6.8520x | 9.3792x |
| confirm/synthetic_confirm/crossover | A2_NL4 | A2_G16384 | 1.0182x | 0.9973x | 1.0435x |
| confirm/synthetic_confirm/crossover | A2_NL4 | A2_SIMPLE_RUN | 0.9935x | 0.9926x | 0.9852x |
| confirm/synthetic_confirm/crossover | A2_NL4 | OFFICIAL_504 | 7.9733x | 6.8336x | 9.7871x |
| confirm/synthetic_confirm/crossover | A2_SIMPLE_RUN | A2_G16384 | 1.0248x | 1.0048x | 1.0592x |
| confirm/synthetic_confirm/crossover | A2_SIMPLE_RUN | OFFICIAL_504 | 8.0251x | 6.8848x | 9.9342x |
| confirm/synthetic_confirm/mixed | A2_G16384 | OFFICIAL_504 | 2.4776x | 3.2991x | 2.0564x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_G16384 | 1.1761x | 0.9975x | 1.2744x |
| confirm/synthetic_confirm/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9944x | 0.9934x | 0.9948x |
| confirm/synthetic_confirm/mixed | A2_NL4 | OFFICIAL_504 | 2.9139x | 3.2908x | 2.6207x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.1827x | 1.0041x | 1.2810x |
| confirm/synthetic_confirm/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9303x | 3.3126x | 2.6343x |
| confirm/synthetic_confirm/newline | A2_G16384 | OFFICIAL_504 | 2.4766x | 3.2968x | 2.0707x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_G16384 | 1.2127x | 0.9970x | 1.3762x |
| confirm/synthetic_confirm/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0240x | 0.9924x | 1.0758x |
| confirm/synthetic_confirm/newline | A2_NL4 | OFFICIAL_504 | 3.0035x | 3.2867x | 2.8497x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | A2_G16384 | 1.1843x | 1.0046x | 1.2792x |
| confirm/synthetic_confirm/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9331x | 3.3119x | 2.6489x |
| confirm/synthetic_confirm/quote | A2_G16384 | OFFICIAL_504 | 2.5165x | 3.2931x | 2.1244x |
| confirm/synthetic_confirm/quote | A2_NL4 | A2_G16384 | 1.1711x | 0.9977x | 1.2667x |
| confirm/synthetic_confirm/quote | A2_NL4 | A2_SIMPLE_RUN | 0.9923x | 0.9936x | 0.9943x |
| confirm/synthetic_confirm/quote | A2_NL4 | OFFICIAL_504 | 2.9469x | 3.2856x | 2.6911x |
| confirm/synthetic_confirm/quote | A2_SIMPLE_RUN | A2_G16384 | 1.1801x | 1.0041x | 1.2740x |
| confirm/synthetic_confirm/quote | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9697x | 3.3068x | 2.7065x |
| confirm/synthetic_confirm/slash | A2_G16384 | OFFICIAL_504 | 2.3651x | 3.0130x | 2.0642x |
| confirm/synthetic_confirm/slash | A2_NL4 | A2_G16384 | 1.1759x | 0.9979x | 1.2752x |
| confirm/synthetic_confirm/slash | A2_NL4 | A2_SIMPLE_RUN | 0.9931x | 0.9931x | 0.9940x |
| confirm/synthetic_confirm/slash | A2_NL4 | OFFICIAL_504 | 2.7810x | 3.0066x | 2.6322x |
| confirm/synthetic_confirm/slash | A2_SIMPLE_RUN | A2_G16384 | 1.1840x | 1.0048x | 1.2828x |
| confirm/synthetic_confirm/slash | A2_SIMPLE_RUN | OFFICIAL_504 | 2.8003x | 3.0274x | 2.6480x |
| confirm/synthetic_confirm/unicode | A2_G16384 | OFFICIAL_504 | 2.6359x | 3.1623x | 2.0946x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_G16384 | 0.9989x | 0.9991x | 0.9982x |
| confirm/synthetic_confirm/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9936x | 0.9929x | 0.9948x |
| confirm/synthetic_confirm/unicode | A2_NL4 | OFFICIAL_504 | 2.6331x | 3.1595x | 2.0909x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | A2_G16384 | 1.0054x | 1.0063x | 1.0034x |
| confirm/synthetic_confirm/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.6502x | 3.1822x | 2.1017x |
| explore/public_original/public | A2_G16384 | OFFICIAL_504 | 1.8914x | 2.5025x | 1.4671x |
| explore/public_original/public | A2_NL4 | A2_G16384 | 1.0040x | 1.0000x | 1.0082x |
| explore/public_original/public | A2_NL4 | A2_SIMPLE_RUN | 1.0006x | 0.9988x | 1.0021x |
| explore/public_original/public | A2_NL4 | OFFICIAL_504 | 1.8990x | 2.5025x | 1.4792x |
| explore/public_original/public | A2_SIMPLE_RUN | A2_G16384 | 1.0034x | 1.0012x | 1.0061x |
| explore/public_original/public | A2_SIMPLE_RUN | OFFICIAL_504 | 1.8979x | 2.5054x | 1.4761x |
| explore/synthetic_explore/crossover | A2_G16384 | OFFICIAL_504 | 7.8328x | 6.8532x | 9.3803x |
| explore/synthetic_explore/crossover | A2_NL4 | A2_G16384 | 1.0178x | 0.9972x | 1.0428x |
| explore/synthetic_explore/crossover | A2_NL4 | A2_SIMPLE_RUN | 0.9935x | 0.9925x | 0.9847x |
| explore/synthetic_explore/crossover | A2_NL4 | OFFICIAL_504 | 7.9725x | 6.8343x | 9.7816x |
| explore/synthetic_explore/crossover | A2_SIMPLE_RUN | A2_G16384 | 1.0245x | 1.0048x | 1.0590x |
| explore/synthetic_explore/crossover | A2_SIMPLE_RUN | OFFICIAL_504 | 8.0249x | 6.8859x | 9.9336x |
| explore/synthetic_explore/mixed | A2_G16384 | OFFICIAL_504 | 2.4784x | 3.2943x | 2.0600x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_G16384 | 1.1765x | 0.9970x | 1.2746x |
| explore/synthetic_explore/mixed | A2_NL4 | A2_SIMPLE_RUN | 0.9937x | 0.9924x | 0.9946x |
| explore/synthetic_explore/mixed | A2_NL4 | OFFICIAL_504 | 2.9159x | 3.2844x | 2.6256x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | A2_G16384 | 1.1839x | 1.0046x | 1.2815x |
| explore/synthetic_explore/mixed | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9342x | 3.3094x | 2.6398x |
| explore/synthetic_explore/newline | A2_G16384 | OFFICIAL_504 | 2.4754x | 3.2972x | 2.0635x |
| explore/synthetic_explore/newline | A2_NL4 | A2_G16384 | 1.2132x | 0.9978x | 1.3789x |
| explore/synthetic_explore/newline | A2_NL4 | A2_SIMPLE_RUN | 1.0241x | 0.9930x | 1.0781x |
| explore/synthetic_explore/newline | A2_NL4 | OFFICIAL_504 | 3.0032x | 3.2899x | 2.8453x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | A2_G16384 | 1.1847x | 1.0048x | 1.2790x |
| explore/synthetic_explore/newline | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9326x | 3.3132x | 2.6393x |
| explore/synthetic_explore/quote | A2_G16384 | OFFICIAL_504 | 2.5172x | 3.2934x | 2.1221x |
| explore/synthetic_explore/quote | A2_NL4 | A2_G16384 | 1.1717x | 0.9977x | 1.2687x |
| explore/synthetic_explore/quote | A2_NL4 | A2_SIMPLE_RUN | 0.9930x | 0.9930x | 0.9952x |
| explore/synthetic_explore/quote | A2_NL4 | OFFICIAL_504 | 2.9495x | 3.2857x | 2.6922x |
| explore/synthetic_explore/quote | A2_SIMPLE_RUN | A2_G16384 | 1.1800x | 1.0047x | 1.2748x |
| explore/synthetic_explore/quote | A2_SIMPLE_RUN | OFFICIAL_504 | 2.9704x | 3.3088x | 2.7053x |
| explore/synthetic_explore/slash | A2_G16384 | OFFICIAL_504 | 2.3518x | 2.9845x | 2.0683x |
| explore/synthetic_explore/slash | A2_NL4 | A2_G16384 | 1.1772x | 0.9975x | 1.2763x |
| explore/synthetic_explore/slash | A2_NL4 | A2_SIMPLE_RUN | 0.9935x | 0.9932x | 0.9933x |
| explore/synthetic_explore/slash | A2_NL4 | OFFICIAL_504 | 2.7684x | 2.9771x | 2.6397x |
| explore/synthetic_explore/slash | A2_SIMPLE_RUN | A2_G16384 | 1.1849x | 1.0044x | 1.2849x |
| explore/synthetic_explore/slash | A2_SIMPLE_RUN | OFFICIAL_504 | 2.7866x | 2.9975x | 2.6574x |
| explore/synthetic_explore/unicode | A2_G16384 | OFFICIAL_504 | 2.6355x | 3.1628x | 2.0950x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_G16384 | 0.9991x | 0.9986x | 0.9978x |
| explore/synthetic_explore/unicode | A2_NL4 | A2_SIMPLE_RUN | 0.9956x | 0.9932x | 0.9969x |
| explore/synthetic_explore/unicode | A2_NL4 | OFFICIAL_504 | 2.6331x | 3.1583x | 2.0904x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | A2_G16384 | 1.0035x | 1.0054x | 1.0009x |
| explore/synthetic_explore/unicode | A2_SIMPLE_RUN | OFFICIAL_504 | 2.6448x | 3.1798x | 2.0968x |

## Density sweep and crossover

The exact density and crossover breakdown is in `summary103.json`.

## Promotion gate

No automatic promotion. Require correctness parity, independent confirmation on both machines,
non-regression on public JSON, and a measurable Stage 2/DOM gain on dense escapes.
